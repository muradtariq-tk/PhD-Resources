import java.io.BufferedReader;
import org.jsoup.Jsoup;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;

import org.jsoup.*;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class main {
	public static void main(String[] args) {
		String[][] csv = loadcsv.loadfile("ML.csv");
		int ttl = csv.length;
		String[][] imdb = new String[ttl][2];
		String reply = "";
		for (int i = 0; i < ttl; i++) {
			System.out.println("ML ID:" + csv[i][0] + ": ");
			reply = getimdbid(csv[i][0]);
			if (reply.contains("timerout")) {
				i = i - 1;
			}
			if (reply.contains("fileexists")) {
				continue;
			}
			imdb[i][0] = csv[i][0];
			imdb[i][1] = reply;
		}
		writecsv.writegeneric("ML2MT.csv", imdb);
	}

	public static String getimdbid(String id) {
		String sd = loadid(id);
		if (sd == null) {
			//writeimacroscript(id);
			//String d = executescript(id);
			return "0";
		} else {
			return sd;
		}

	}

	public static String writeimacroscript(String id) {
		String path = "C:\\Users\\Murad\\Documents\\iMacros\\Macros\\";
		String scrpit = "VERSION BUILD=9030808 RECORDER=FX \n TAB T=1 \n URL GOTO=https://movielens.org/movies/"
				+ id
				+ " \n TAG POS=1 TYPE=A ATTR=TXT:imdb \n SAVEAS TYPE=HTM FOLDER=d:\\reports FILE="
				+ id + ".html \n TAB CLOSE \n TAB CLOSE ";
		try (Writer writer = new BufferedWriter(new OutputStreamWriter(
				new FileOutputStream(path + "mlo.iim"), "utf-8"))) {
			writer.write(scrpit);
			return "done";
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "done";
	}

	public static String whilefilenotexist(String id) {
		int counter = 0;
		while (loadid(id) == null && counter < 60) {
			try {
				Thread.sleep(1000);
				System.out.print(".");
				counter++;
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if (counter > 60) {
			return "retry";
		}
		return "created";
	}

	public static void deletefile(String id) {
		File file = new File("D:\\reports\\" + id + ".html");
		if (file.exists()) {
			//file.delete();
		}
	}

	public static String executescript(String idin) {
		String stat1 = "";
		try {
			Runtime.getRuntime()
					.exec("\"C:\\Program Files (x86)\\Mozilla Firefox\\firefox.exe\"  imacros://run/?m=mlo.iim");
			stat1 = whilefilenotexist(idin);
			String id = loadid(idin);
			
			System.out.println(":" + id);
			//deletefile(idin);
			if(id==null){return stat1;}
			return id;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public static String loadid(String id) {
		StringBuilder contentBuilder = new StringBuilder();
		File in = new File("D:\\reports\\" + id + ".html");
		try {
			Document doc = Jsoup.parse(in, null);
			Elements e = doc.getElementsByTag("meta");
			for (int i = 0; i < e.size(); i++) {
				String temp = e.get(i).toString();
				if (temp.contains("apple-itunes-app")) {
					String[] spl = temp.split("/tt");
					spl = spl[1].split("\\?src");
					return spl[0];
				}
			}
			// System.out.println(doc.toString());

		} catch (IOException e) {
			return null;
		}
		// BufferedReader in = new BufferedReader(new FileReader());
		return null;

	}

	public static void write(String fn, String cnt) {
		fn = "pages\\" + fn;
		BufferedWriter writer = null;
		try {
			writer = new BufferedWriter(new FileWriter(fn));
			writer.write(cnt);

		} catch (IOException e) {
		} finally {
			try {
				if (writer != null)
					writer.close();
			} catch (IOException e) {
			}
		}
	}
}
