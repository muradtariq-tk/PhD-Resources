package FB;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.Formatter;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Scanner;





import com.restfb.DefaultFacebookClient;
import com.restfb.FacebookClient;
import com.restfb.Parameter;
import com.restfb.Version;
import com.restfb.json.JsonArray;
import com.restfb.json.JsonObject;



public class All_in_one {
	
	private static JsonObject one_page;
	private static FacebookClient fb=new DefaultFacebookClient("CAAW4DPWRJZA4BACzTcJ2eDZCyP6IZBttyu21HPAcSgvPQ2FXaSWipd3nwItHPFbfNSfNfPm5nZAAZB72xXab7ZAG6MpMJyukQdz1MukUsLCna5WViNNiEakfBHbqScr5XYcXSRevbvqYHCdZCjToDWqa3QwWtI91M1M5Ax0fCukclgm3BAFMHCDwfBbsoIP364",Version.VERSION_2_4);
	
public static String get_dash(String from, String what)
{
	int temp=from.indexOf(what)+what.length();
	int endd=from.indexOf('&',temp);
	if(endd!=-1)
	return from.substring(temp, endd);
	else
		return from.substring(temp); 
}

public static String make_fields_string(String...fields)
{
	  StringBuilder query_string=new StringBuilder("");
	   for(short i=0;i<fields.length;i++)
	   {
		   query_string=query_string.append(fields[i]);
		   if(i<fields.length-1)
			   query_string=query_string.append(",");
	   }
	   return query_string.toString();
}

private static void recursive(JsonObject m_obj, final FileWriter fw) throws IOException
{
	Object j;
	String js;

	
	Iterator ite=m_obj.keys();
	
	do{
		j=ite.next(); 
	     js=(String)j;
	     if( (j.equals("paging")||j.equals("cursors")))
	    	 return;
		 if(m_obj.get(js) instanceof JsonObject)
		recursive((JsonObject)m_obj.get(js),fw);
		 else if(m_obj.get(js) instanceof JsonArray)
		 {
			 JsonArray arr=(JsonArray) m_obj.get(js);
			 int n=arr.length();
			 if(n==0)
				 return;
			 for(int i=0;i<n;i++)
			 {
				 recursive(arr.getJsonObject(i),fw);
			 }
		 }
		 else
		 {
			 fw.write(js+"   "+m_obj.get(js)+"    **");	 
		     System.out.println(js+"  "+m_obj.get(js));
			 
		 }
		 
	}while(ite.hasNext());
	fw.write("\n");
	
}
private static String make_struct(String write)
{

	StringBuilder s=new StringBuilder();
            
    return "";
 	
 	/*	for(int i=0;i<arr.length();i++)
	{
	   try { 
		ob=(JsonObject)arr.get(i);
	    c=ob.getJsonObject("comments");
	    c=c.getJsonObject("summary");
	    l=ob.getJsonObject("likes");
	    l=l.getJsonObject("summary");
		System.out.println(ob.get("id")+"   "+l.get("total_count"));
		s.append(has(ob,"id")).append(l.has("total_count")?l.get("total_count"):"null").append(c.has("total_count")?c.get("total_count"):"null").append(ob.has("caption")?ob.get("caption"):"null").append(ob.has("description")?ob.get("description"):"null").append(ob.has("story")?ob.get("story"):"null");
		s.append(ob.has("message")?ob.get("message"):"null");
		c=ob.get("caption");
	   }catch(Exception e)
	   {
		   ;
	   }

	}*/
}

private static void do_all(String page_id,int num,short exp,String... fields)
{
		String until=null;
		String paging=null;
		String next=null;
		  FileWriter fw =null; 
   if(new File("experiment//Exp_"+exp+"//p_"+page_id+"_"+num+"//next.txt").exists() || !new File("experiment//Exp_"+exp+"//p_"+page_id+"_"+num+"//post_ids.txt").exists())
   {
try {
     String fields_string=make_fields_string(fields);
	one_page=check_existence_and_fetch("experiment//Exp_"+exp+"//p_"+page_id+"_"+num+"//next.txt",page_id+"/posts",fields_string);
	
	fw= new FileWriter("experiment//Exp_"+exp+"//p_"+page_id+"_"+num+"//post_ids.txt",true);
	do{
		
		if(one_page.has("paging"))
		{
		next=one_page.getJsonObject("paging").get("next").toString();
		 until=get_dash(next,"until=");
		 paging=get_dash(next,"__paging_token=");
		}
		
		 recursive(one_page,fw);
	//recursive(obj);
         
		   
		  
	     //  	fw.write(ob.get("id").toString()+"  "+ob.get("created_time").toString()+"  "+c.get("total_count")+"  "+l.get("total_count")+"\n");
		    
		if(until!=null)
		 one_page=fb.fetchObject(page_id+"/posts",JsonObject.class,Parameter.with("limit", 100),Parameter.with("fields", fields_string),Parameter.with("until", until),Parameter.with("__paging_token", paging));
		 
	}while(one_page.getJsonArray("data").length()>0&&one_page.has("paging"));
	new File("experiment//Exp_"+exp+"//p_"+page_id+"_"+num+"//next.txt").delete();
}
catch(Exception f)
{
	System.out.println("Network Error...Try again later");
	f.printStackTrace();
	try {
		if(until!=null) {
		Formatter ff = new Formatter("experiment//Exp_"+exp+"//p_"+page_id+"_"+num+"//next.txt");
		ff.format("%s\n%s", until,paging);
		ff.close();
		}
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
finally {
	if(fw!=null)
		try {
			fw.close();
			System.out.println("in finally");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
}
   }    
}
private static JsonObject check_existence_and_fetch(String file_name,String url_pattern,String fields_string) throws FileNotFoundException
{
	
	File fff = new File(file_name);
	 JsonObject jj;
	if(fff.exists())
	{
		Scanner in=new Scanner( new File(file_name ) );
		String[][] para=new String[2][2];
		if(file_name.contains("comments"))
		{
			para[0][0]="after";
			para[1][0]="order";
		}
		else if(file_name.contains("likes"))
		{
			String after=in.nextLine();
			in.close();
		 return fb.fetchObject(url_pattern,JsonObject.class,Parameter.with("limit", 1000),Parameter.with("fields", fields_string),Parameter.with("after",after));
		}
		else
		{
			para[0][0]="until";
			para[1][0]="__paging_token";
		}
		para[0][1]=in.nextLine();
		para[1][1]=in.nextLine();
		in.close();
		
		return fb.fetchObject(url_pattern,JsonObject.class,Parameter.with("limit", 100),Parameter.with("fields", fields_string),Parameter.with(para[0][0], para[0][1]),Parameter.with(para[1][0], para[1][1]));
		
	}
	else
		jj= fb.fetchObject(url_pattern, JsonObject.class,Parameter.with("limit", 100),Parameter.with("fields", fields_string));
        return jj;  
         
}

private static void check_like_work(String page_id, int num,short exp)
{
	 System.out.println("\n\nReading likes data for page:"+page_id);
	   String id_number="" ;
	   File fid=null;
	  try {
	   Scanner in=new Scanner(new File("experiment//Exp_"+exp+"//p_"+page_id+"_"+num+"//post_ids.txt"));
	   boolean bb=!new File("experiment//Exp_"+exp+"//p_"+page_id+"_"+num+"//likes_data").exists();
       fid=new File("experiment//Exp_"+exp+"//p_"+page_id+"_"+num+"//likes_data//id_number.txt");
         if(fid.exists())
          {
      		 Scanner ss=new Scanner( new File("experiment//Exp_"+exp+"//p_"+page_id+"_"+num+"//likes_data//id_number.txt" ) );
      		id_number=ss.nextLine();
      		ss.close();
         	bb=true;	 
          }
          else
          {
          do {
          id_number=in.nextLine();
          }while(!id_number.contains(page_id));
          int i2;
          i2=id_number.indexOf("    *");
        	id_number=id_number.substring(id_number.indexOf(page_id),i2);
          }
          if(bb)
          {
          do{ 
        	  int i2;
    	       like_dealer(id_number,"experiment//Exp_"+exp+"//p_"+page_id+"_"+num);
    	       do {
    	    	      id_number=in.nextLine();
    	    	      }while(!id_number.contains(page_id));
    	       i2=id_number.indexOf("    *");
    	      	id_number=id_number.substring(id_number.indexOf(page_id),i2);
          }while(in.hasNext());
          }
          fid.delete();in.close();
         
	}catch(NoSuchElementException no)
	  {
		fid.delete();
	  }
	  catch(Exception e)
	  {
		try {
			Formatter fr=new Formatter("experiment//Exp_"+exp+"//p_"+page_id+"_"+num+"//likes_data//id_number.txt");
			fr.format("%s", id_number);
			fr.close();
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}
	  }
	}

private static void like_dealer(String post_id,String file_path) throws Exception
{
	new File(file_path+"//likes_data").mkdir();
	String next=null;String after=null;
	 FileWriter fw =null; 
	try {
         String fields_string=make_fields_string("id","name");
		JsonObject one_like_page=check_existence_and_fetch(file_path+"//likes_data//next_likes.txt",post_id+"/likes",fields_string);
		fw= new FileWriter(file_path+"//likes_data//user_"+post_id+".txt",true);
		boolean b=true;
		do{
			
			if(one_like_page.has("paging")&&one_like_page.getJsonObject("paging").has("next"))
			{
			next=one_like_page.getJsonObject("paging").get("next").toString();
			//after =get_dash(next,"after=");
			after=one_like_page.getJsonObject("paging").getJsonObject("cursors").get("after").toString();
			// System.out.println(next+"\n\nafter "+after);
			}
			else 
				 b=false;
			
	recursive(one_like_page,fw);
	    	if(after!=null)
	    	{
			 one_like_page=fb.fetchObject(post_id+"/likes",JsonObject.class,Parameter.with("limit", 1000),Parameter.with("fields",fields_string ),Parameter.with("after",after));
			// after=null;
	    	}
			 
		}while(one_like_page.has("paging")&&b);
		new File(file_path+"//likes_data//next_likes.txt").delete();
	}
	catch(Exception f)
	{
		System.out.println("Network Error OR FB server is down...Try again later ");
		//f.printStackTrace();
		try {
			if(after!=null) {
			Formatter ff = new Formatter(file_path+"//likes_data//next_likes.txt");
			ff.format("%s", after);
			ff.close();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		throw new Exception();
	}finally {
		if(fw!=null)
			try {
				fw.close();
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	} 

}

public static void comment_dealer(String post_id,String file_path) throws Exception
{
	new File(file_path+"//comments_data").mkdir();
	String next=null;String after=null; String order=null;
	 FileWriter fw =null;
	 FileWriter fw2 =null;
	try {
         String fields_string=make_fields_string("id","like_count","message","from","attachment","message_tags");
		JsonObject one_comment_page=check_existence_and_fetch(file_path+"//comments_data//next_comments.txt",post_id+"/comments",fields_string);
		fw= new FileWriter(file_path+"//comments_data//"+post_id+".txt",true);
		fw2= new FileWriter(file_path+"//comments_data//user_"+post_id+".txt",true);
		boolean b=true;
		do{
			
			if(one_comment_page.has("paging")&&one_comment_page.getJsonObject("paging").has("next"))
			{
			next=one_comment_page.getJsonObject("paging").get("next").toString();
			//after =get_dash(next,"after=");
			after=one_comment_page.getJsonObject("paging").getJsonObject("cursors").get("after").toString();
			 order=get_dash(next,"order=");
			}
			else 
				 b=false;
			
			recursive(one_comment_page,fw);

	    	/*JsonArray arr	=one_comment_page.getJsonArray("data");
	    	JsonObject ob,from,attach,tag;
	    	int  n=arr.length();
	    	for(int i=0;i<n;i++)
	    	{
	    		try {
	    	    ob=(JsonObject)arr.get(i);
	    	    from=ob.getJsonObject("from");
	    	    System.out.println("STRUCT*:COMMENTID:\n"+ob.get("id")+"STRUCT*:LIKE_COUNT:\n"+ob.get("like_count")+"  "+from.get("id")+"  "+from.get("name"));
	    	    fw2.write(from.get("id").toString()+"    "+from.get("name")+"\n");
	    		fw.write("STRUCT*:COMMENTID:\n"+ob.get("id")+"\n"+"STRUCT*:LIKE_COUNT:\n"+ob.get("like_count")+"   "+ob.get("message").toString());
	    		  attach=ob.getJsonObject("attachment");
		    	    tag=ob.getJsonObject("message_tags"); 
		    	    fw.write("   "+attach.get("description")+"  "+attach.get("title")+"   "+tag.get("name"));
	    
	    		}catch(Exception e)
	    		{
	    			;
	    		}
	    		fw.write("\n");
	    	}*/
	    	if(after!=null)
	    	{
			 one_comment_page=fb.fetchObject(post_id+"/comments",JsonObject.class,Parameter.with("limit", 1000),Parameter.with("fields",fields_string ),Parameter.with("after",after),Parameter.with("order", order));
			// after=null;
	    	}
			 
		}while(one_comment_page.has("paging")&&b);
		new File(file_path+"//comments_data//next_comments.txt").delete();
	}
	catch(Exception f)
	{
		System.out.println("Network Error...Try again later (comment)");
		//f.printStackTrace();
		try {
			if(after!=null) {
			Formatter ff = new Formatter(file_path+"//comments_data//next_comments.txt");
			ff.format("%s\n%s", after,order);
			ff.close();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		throw new Exception();
	}finally {
		if(fw!=null)
			try {
				fw.close();
				fw2.close();
				System.out.println("in comment finally");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	} 
	
	
}
//}
public static void check_work() 
{
	File fi=new File("experiment");
	int counter=0;
	if(fi.exists())
	 counter=fi.list(new FilenameFilter() {
		    public boolean accept(File directory, String fileName) {
		        return fileName.startsWith("Exp_")&&fileName.endsWith(".csv");
		    }
		}).length;
	
   for(short j=1;j<=counter;j++)
   {
	String[][] s=loadcsv.loadfile("experiment//Exp_"+j+"//pages.csv");
	for(short i=2;i<s.length;i++)
	{
   // check_page_work(s[i][0],i-1,j);
    check_comment_work(s[i][0],i-1,j);
    //check_like_work(s[i][0],i-1,j);
	}
   }
   
	
}
private static void check_comment_work(String page_id, int num,short exp)
{
	 System.out.println("\n\nCollecting Comments data for page:"+page_id);
	   String id_number="" ;
	   File fid=null;
	  try {
	   Scanner in=new Scanner(new File("experiment//Exp_"+exp+"//p_"+page_id+"_"+num+"//post_ids.txt"));
	   boolean bb=!new File("experiment//Exp_"+exp+"//p_"+page_id+"_"+num+"//comments_data").exists();
	    fid=new File("experiment//Exp_"+exp+"//p_"+page_id+"_"+num+"//comments_data//id_number.txt");
      if(fid.exists())
      {
      	 
        Scanner inn=new Scanner(new File("experiment//Exp_"+exp+"//p_"+page_id+"_"+num+"//comments_data//id_number.txt"));
        id_number=inn.nextLine();
       inn.close();
     
      	bb=true;	 
      }
      else
      {
      do {
      id_number=in.nextLine();
      }while(!id_number.contains(page_id));
      int i2;
      i2=id_number.indexOf("    *");
    	id_number=id_number.substring(id_number.indexOf(page_id),i2);
      }
      if(bb)
     do { 
    	  int i2;
	       comment_dealer(id_number,"experiment//Exp_"+exp+"//p_"+page_id+"_"+num);
	       do {
	    	      id_number=in.nextLine();
	    	      }while(!id_number.contains(page_id));
	       i2=id_number.indexOf("    *");
	      	id_number=id_number.substring(id_number.indexOf(page_id),i2);
      }while(in.hasNext());
      fid.delete();in.close();
	}catch(NoSuchElementException no)
	  {
	       fid.delete();
	  }
	  catch(Exception e)
	  {
		try {
			Formatter fr=new Formatter("experiment//Exp_"+exp+"//p_"+page_id+"_"+num+"//comments_data//id_number.txt");
			fr.format("%s", id_number);
			fr.close();
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}
	  }
	}

private static void check_page_work(String page_id, int num,short exp)
{
	System.out.println("\n\nCollecting posts data for page:"+page_id);
	File f=new File("experiment//Exp_"+exp+"//p_"+page_id+"_"+num);
	if(!f.isDirectory())
		f.mkdir();
		do_all(page_id,num,exp,"id","created_time","likes.summary(true).limit(0)","comments.summary(true).limit(0)","message","caption","description","message_tags","story","with_tags");
}
}









/*public static void do_all_2(String page_id,String... fields)
{
	 String fields_string=new String("");
	   for(short i=0;i<fields.length;i++)
	   {
		   fields_string=fields_string+fields[i];
		   if(i<fields.length-1)
			   fields_string=fields_string+",";
	   }
	try {
	FacebookClient fb=new DefaultFacebookClient("CAAW4DPWRJZA4BACzTcJ2eDZCyP6IZBttyu21HPAcSgvPQ2FXaSWipd3nwItHPFbfNSfNfPm5nZAAZB72xXab7ZAG6MpMJyukQdz1MukUsLCna5WViNNiEakfBHbqScr5XYcXSRevbvqYHCdZCjToDWqa3QwWtI91M1M5Ax0fCukclgm3BAFMHCDwfBbsoIP364");
	Connection<JsonObject> post = fb.fetchConnection(page_id+"/posts", JsonObject.class,Parameter.with("limit", 100),Parameter.with("fields", fields_string));
	
	   LinkedList<String[][]> arrlist=new LinkedList<String[][]>();
	   short j;
		for(j=0;j<fields.length;j++)
		{
			if(fields[j].contains("likes"))
				fields[j]="likesCount";
			if(fields[j].contains("comments"))
				fields[j]="commentsCount";
			char ch=fields[j].toCharArray()[0];
			fields[j]=fields[j].replaceFirst(""+ch, ""+(char)(ch-32));
			fields[j]="get"+fields[j];
		}
	   for(List<JsonObject> p:post)
				for(JsonObject single:p)
				{
					String[][] arr=new String[1][fields.length+1];
					Method	method;
					for(short i=0;i<fields.length;i++)
					{
				    	method = Post.class.getDeclaredMethod(fields[i]);
				    	arr[0][i+1]=(method.invoke(single)==null?"null":method.invoke(single).toString());
						System.out.print("  *"+fields[i]+" "+method.invoke(single));
					}
						
					//method = FacebookType.class.getDeclaredMethod("getId");
					//arr[0][0]=single.getId();
					arrlist.add(arr);
				//System.out.println(single.getLikes().getData().size());
				//single.getLikes().getData().forEach((id)->System.out.println(id.getId()));//.size());	
			           // single.getComments().getData().forEach((id)->System.out.println(id.getId()));	
				}
	
	
	}catch(Exception e)
	{
		e.printStackTrace();
	}
    
}*/


