package FB;

import java.lang.reflect.InvocationTargetException;
import java.util.Scanner;

public class Driver {
	
	public static void main(String[] args) throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException 
	{
		System.out.println("Press \n1 to run \"Program 1\"\n2 to run \"Program 2\"");
		int n=new Scanner(System.in).nextInt();
		if(n==1)
		{
           Moniter m=new Moniter();
	       m.make_directory();
		}
		else if(n==2)
		Strucht_all_in_one.check_work();
		else
			System.out.println("Wrong input....");	
	}
}
