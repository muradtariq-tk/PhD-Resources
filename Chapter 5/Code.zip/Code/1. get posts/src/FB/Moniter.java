package FB;

import java.io.File;
import java.io.FilenameFilter;
import java.util.Scanner;

import com.restfb.DefaultFacebookClient;
import com.restfb.FacebookClient;
import com.restfb.Version;
import com.restfb.types.Page;
import com.restfb.exception.*;
//import com.restfb.json.JSONObject;





public class Moniter {

public void make_directory()
	{
		int counter;
		if(!new File("experiment").isDirectory())
		{
           counter=1;
		   new File("experiment").mkdir();
		   
		}
		else
		{
			 counter=new File("experiment").list(new FilenameFilter() {
			    public boolean accept(File directory, String fileName) {
			        return fileName.startsWith("Exp_")&&fileName.endsWith(".csv");
			    }
			}).length+1;
		}
                Scanner in=new Scanner(System.in);
				System.out.println("Enter number of urls");
				
				int num=in.nextInt()+1;
				int ids=num;
				in.nextLine();
				String[][] arr=new String[num][1];
				System.out.println("Enter experiment title\n");
				arr[0][0]=in.nextLine();
			    num--;
		        do
				{
					System.out.println("Enter page name ");
					arr[num][0]=in.nextLine();
				}while(--num>0);
		        String[][] arrof_ids=new String[ids][1];
		        arrof_ids[0][0]="\n";
                  FacebookClient fb=new DefaultFacebookClient("EAACEdEose0cBACmAHquXZBQk7MGHpXdhBXC8VPiyfKxYFFZBwybHL1X2povTUT64dqBdW6y7fZCjG9hZCCe3TnRwtHSJYXJXok0gcvdKlRuEJtkWhCRQjw46gLoiox4wbTpjHMU2GFdbNGJOLcLWR3uWOZAwlgLE7zwDWI1X4wOtW5UtArqnVJj9vSHUxDdYZD",Version.VERSION_2_4);
                  boolean che=true;
                  for(num=1;num<arr.length;num++)
                     {
                	  try {
                	  String page_id="15925638948";//fb.fetchObject(arr[num][0],Page.class).getId();
                	  arrof_ids[num][0]=page_id;
                      new File("experiment//Exp_"+counter).mkdir();
                 
                      writecsv.writegeneric("experiment//Exp_"+counter+".csv", arr);
                	 // new File("experiment//Exp_"+counter+"//p_"+page_id+"_"+num).mkdir();
                    }catch(FacebookOAuthException e)
                	  {
                    	che=false;
                		  System.out.print("You entered invalid page name: "+arr[num][0]);
                	  }
                	  catch(FacebookNetworkException f)
                	  {
                		  che=false;
                		  System.out.print("\nnetwork error.....\nTry again later");
                		  break;
                	  }
                  }
                  if(che)
                  {
                  writecsv.writegeneric("experiment//Exp_"+counter+"//pages.csv", arrof_ids);
                  System.out.print("\n\n!!!!!Done");
                  }
	}
		
}
