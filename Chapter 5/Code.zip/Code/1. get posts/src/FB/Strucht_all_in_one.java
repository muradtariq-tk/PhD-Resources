package FB;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.Formatter;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Scanner;

import com.restfb.DefaultFacebookClient;
import com.restfb.FacebookClient;
import com.restfb.Parameter;
import com.restfb.Version;
import com.restfb.json.JsonArray;
import com.restfb.json.JsonObject;

public class Strucht_all_in_one {

	private static int index = 0;
	private static String[][] arr;
	private static JsonObject one_page;
	private static FacebookClient fb = new DefaultFacebookClient(
			"EAACEdEose0cBAAZCV9dULPpvguhsLCuN4tZCQRZCfKgjjaAmNZB4levgwbu2EPqW3fwHDgKRkuLPm0ZAJAKPOcth2jsYel6Lyty2Jn7Q6Dz9wlmHQCW7Fd1HyaQiBPIPrOHeKIl4mCKI4QGsZAJkE8U7ZAydZCDqusF422xquwMdhdHRlQBSMDzlmZAy6M9iO0ZBIZD",
			Version.VERSION_2_6);

	public static String get_dash(String from, String what) {
		int temp = from.indexOf(what) + what.length();
		int endd = from.indexOf('&', temp);
		if (endd != -1)
			return from.substring(temp, endd);
		else
			return from.substring(temp);
	}

	public static String make_fields_string(String... fields) {
		StringBuilder query_string = new StringBuilder("");
		for (short i = 0; i < fields.length; i++) {
			query_string = query_string.append(fields[i]);
			if (i < fields.length - 1)
				query_string = query_string.append(",");
		}
		return query_string.toString();
	}

	// purpose of this function is to parse the json and store each key value
	// pair in file.This function parses of three types.json containing posts
	// data, comments data and likes data.
	// first argument is json object to be parsed.
	// second & third arguments are file objects to be written to.
	// fourth object is file path of third file.(second file is already
	// initilized)
	// fifth parameter is Stringbuilder
	private static void recursive(JsonObject m_obj, FileWriter fw,
			FileWriter fw2, String path, StringBuilder sb) throws IOException {
		Object j;
		String js;
		FileWriter temp = fw;
		boolean should_close = false;
		if (fw2 == null)
			should_close = false;

		Iterator ite = m_obj.keys();

		do {
			j = ite.next();
			js = (String) j;
			if (js.equals("from") && fw2 != null)
				fw = fw2;

			if ((js.equals("paging") || js.equals("cursors")))
				return;
			if (m_obj.get(js) instanceof JsonObject) {

				recursive((JsonObject) m_obj.get(js), fw, fw2, path, sb);
			} else if (m_obj.get(js) instanceof JsonArray) {
				JsonArray arr = (JsonArray) m_obj.get(js);
				int n = arr.length();
				if (n == 0)
					return;
				for (int i = 0; i < n; i++) {
					recursive(arr.getJsonObject(i), fw, fw2, path, sb);
				}
			} else {
				if (fw == fw2) {
					if (js.equals("id"))
						fw.write(m_obj.get(js).toString() + "\n");
				} else {
					if (path.length() > 0) {
						if (js.contains("id")
								&& m_obj.get(js).toString().contains("_")) {
							write_id(m_obj.get(js).toString(), fw);
							path = path + m_obj.get(js).toString() + ".txt";
							fw2 = new FileWriter(path, true);
						} else {
							if (fw2 == null) {
								// if(!(sb.length()>5&& js.contains("time")))
								sb.append("STRUCT*:" + js.toUpperCase() + ":\n"
										+ m_obj.get(js).toString() + "\n");
							} else {

								write_message(js, m_obj.get(js).toString(),
										fw2, sb.toString());
								sb.setLength(0);
							}
						}
					} else
						fw.write("STRUCT*:" + js.toUpperCase() + ":\n"
								+ m_obj.get(js) + "\n");
				}

			}
			fw = temp;
		} while (ite.hasNext());
		// fw=temp;
		if (path.contains("txt"))
			fw2.close();
		if (should_close)
			fw2.close();
		// fw.write("\n");

	}

	private static void post_recursive(final JsonObject m_obj)
			throws IOException {
		Object j;
		String js;

		Iterator ite = m_obj.keys();

		do {
			j = ite.next();
			js = (String) j;
			if ((js.equals("paging") || js.equals("cursors")))
				return;
			if (m_obj.get(js) instanceof JsonObject)
				post_recursive((JsonObject) m_obj.get(js));
			else if (m_obj.get(js) instanceof JsonArray) {
				JsonArray array = (JsonArray) m_obj.get(js);
				int n = array.length();
				if (n == 0)
					return;
				for (int i = 0; i < n; i++) {
					if (js.equals("data"))
						arr[index++][0] = "new data";
					post_recursive(array.getJsonObject(i));
				}
			} else {

				if (js.equals("has_liked")) {
					arr[index][0] = "likes";
					arr[index++][1] = m_obj.get("total_count").toString();
					break;
				} else if (js.equals("offset")) {
					arr[index][0] = "tag_names";
					arr[index++][1] = m_obj.get("name").toString();
					arr[index][0] = "tag_ids";
					arr[index++][1] = m_obj.get("id").toString();
					break;
				} else if (js.equals("can_comment")) {
					arr[index][0] = "comments";
					arr[index++][1] = m_obj.get("total_count").toString();
					break;
				} else if (js.equals("count")) {
					arr[index][0] = "shares";
					arr[index++][1] = m_obj.get(js).toString();

				} else {
					arr[index][0] = js;
					arr[index++][1] = m_obj.get(js).toString();
				}
			}

		} while (ite.hasNext());

	}

	private static void write_message(String key, String value,
			final FileWriter fw2, String sb) throws IOException {
		fw2.write(sb + "STRUCT*:" + key.toUpperCase() + ":\n" + value + "\n");
	}

	private static void recursive(JsonObject m_obj, final FileWriter fw)
			throws IOException {
		Object j;
		String js;

		Iterator ite = m_obj.keys();

		do {
			j = ite.next();
			js = (String) j;
			if ((j.equals("paging") || j.equals("cursors")))
				return;
			if (m_obj.get(js) instanceof JsonObject)
				recursive((JsonObject) m_obj.get(js), fw);
			else if (m_obj.get(js) instanceof JsonArray) {
				JsonArray arr = (JsonArray) m_obj.get(js);
				int n = arr.length();
				if (n == 0)
					return;
				for (int i = 0; i < n; i++) {
					recursive(arr.getJsonObject(i), fw);
				}
			} else {
				fw.write(js + "   " + m_obj.get(js) + "    **");
				System.out.println(js + "  " + m_obj.get(js));

			}

		} while (ite.hasNext());
		fw.write("\n");

	}

	private static void write_id(String value, final FileWriter fw)
			throws IOException {

		fw.write(value + "\n");

	}

	private static void do_all(String page_id, int num, short exp,
			String... fields) {
		String until = null;
		String paging = null;
		String next = null;
		FileWriter fw = null;
		FileWriter fw2 = null;
		if (new File("experiment//Exp_" + exp + "//p_" + page_id + "_" + num
				+ "//next.txt").exists()
				|| !new File("experiment//Exp_" + exp + "//p_" + page_id + "_"
						+ num + "//post_ids.txt").exists()) {
			try {
				String fields_string = make_fields_string(fields);
				one_page = check_existence_and_fetch("experiment//Exp_" + exp
						+ "//p_" + page_id + "_" + num + "//next.txt", page_id
						+ "/posts", fields_string);
				new File("experiment//Exp_" + exp + "//p_" + page_id + "_"
						+ num + "//post_message").mkdir();
				// fw2= new
				// FileWriter("experiment//Exp_"+exp+"//p_"+page_id+"_"+num+"//post_message//",true);
				fw = new FileWriter("experiment//Exp_" + exp + "//p_" + page_id
						+ "_" + num + "//post_ids.txt", true);
				do {

					if (one_page.has("paging")) {
						next = one_page.getJsonObject("paging").get("next")
								.toString();
						until = get_dash(next, "until=");
						paging = get_dash(next, "__paging_token=");
					}
					// StringBuilder sb=new StringBuilder();
					// recursive(one_page,fw,fw2,"experiment//Exp_"+exp+"//p_"+page_id+"_"+num+"//post_message//",sb);
					index = 0;
					arr = new String[1500][2];
					post_recursive(one_page);
					StringBuilder sb = new StringBuilder();
					int tag_ids = 0;
					int tag_names = 0;
					int i = 1;
					do {
						// System.out.println(arr[i][0]+"  "+arr[i][1]);
						if (arr[i][0] != null) {
							if (arr[i][0].equals("new data")) {

								if (fw2 != null) {
									if (tag_ids != 0)
										sb.append(
												"STRUCT*:TAG_IDS:\n"
														+ arr[tag_ids][1]
														+ "\n").append(
												"STRUCT*:TAG_NAMES:\n"
														+ arr[tag_names][1]
														+ "\n");
									tag_ids = tag_names = 0;
									fw2.write(sb.toString());
									// fw2.flush();
									sb.setLength(0);
								}
								i++;
							}
							if (arr[i][0].equals("id")
									&& arr[i][1].contains("_")) {
								if (fw2 != null)
									fw2.close();
								fw.write(arr[i][1] + "\n");
								fw2 = new FileWriter("experiment//Exp_" + exp
										+ "//p_" + page_id + "_" + num
										+ "//post_message//" + arr[i][1]
										+ ".txt");

							} else if (arr[i][0].equals("tag_ids")) {
								if (tag_ids == 0)
									tag_ids = i;
								else
									arr[tag_ids][1] += " ," + arr[i][1];

							} else if (arr[i][0].equals("tag_names")) {
								if (tag_names == 0)
									tag_names = i;
								else
									arr[tag_names][1] += " ," + arr[i][1];
							} else {

								sb.append("STRUCT*:" + arr[i][0].toUpperCase()
										+ ":\n" + arr[i][1] + "\n");
							}
						}
						i++;
					} while (i < 1500);
					if (fw2 != null) {
						fw2.write(sb.toString());
						fw2.close();
					}

					if (until != null)
						one_page = fb.fetchObject(page_id + "/posts",
								JsonObject.class, Parameter.with("limit", 100),
								Parameter.with("fields", fields_string),
								Parameter.with("until", until),
								Parameter.with("__paging_token", paging));

				} while (one_page.getJsonArray("data").length() > 0
						&& one_page.has("paging"));
				new File("experiment//Exp_" + exp + "//p_" + page_id + "_"
						+ num + "//next.txt").delete();
			} catch (Exception f) {
				// System.out.println("Network Error...Try again later");
				f.printStackTrace();
				try {
					if (until != null) {
						Formatter ff = new Formatter("experiment//Exp_" + exp
								+ "//p_" + page_id + "_" + num + "//next.txt");
						ff.format("%s\n%s", until, paging);
						ff.close();
					}
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} finally {
				if (fw != null && fw2 != null)
					try {
						fw2.close();
						fw.close();
						System.out.println("in finally");
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
		}
	}

	private static JsonObject check_existence_and_fetch(String file_name,
			String url_pattern, String fields_string)
			throws FileNotFoundException {

		File fff = new File(file_name);
		JsonObject jj;
		if (fff.exists()) {
			Scanner in = new Scanner(new File(file_name));
			String[][] para = new String[2][2];
			if (file_name.contains("comments")) {
				para[0][0] = "after";
				para[1][0] = "order";
			} else if (file_name.contains("likes")) {
				String after = in.nextLine();
				in.close();
				return fb.fetchObject(url_pattern, JsonObject.class,
						Parameter.with("limit", 1000),
						Parameter.with("fields", fields_string),
						Parameter.with("after", after));
			} else {
				para[0][0] = "until";
				para[1][0] = "__paging_token";
			}
			para[0][1] = in.nextLine();
			para[1][1] = in.nextLine();

			if (!para[0][1].split("//")[0].contains("https")) {
				para[0][1] = "https" + para[0][1];
			}

			if (!para[1][1].split("//")[0].contains("https")) {
				para[1][1] = "https" + para[1][1];
			}

			in.close();

			return fb.fetchObject(url_pattern, JsonObject.class,
					Parameter.with("limit", 100),
					Parameter.with("order", "chronological"),
					Parameter.with("fields", fields_string),
					Parameter.with(para[0][0], para[0][1]),
					Parameter.with(para[1][0], para[1][1]));

		} else
			jj = fb.fetchObject(url_pattern, JsonObject.class,
					Parameter.with("limit", 100),
					Parameter.with("order", "reverse_chronological"),
					Parameter.with("fields", fields_string));
		return jj;

	}

	private static void check_like_work(String page_id, int num, short exp) {
		System.out.println("\n\nReading likes data for page:" + page_id);
		String id_number = null;
		File fid = null;
		try {
			Scanner in = new Scanner(new File("experiment//Exp_" + exp + "//p_"
					+ page_id + "_" + num + "//post_ids.txt"));
			boolean bb = !new File("experiment//Exp_" + exp + "//p_" + page_id
					+ "_" + num + "//likes_data").exists();
			fid = new File("experiment//Exp_" + exp + "//p_" + page_id + "_"
					+ num + "//likes_data//id_number.txt");
			String st = null;
			if (fid.exists()) {
				Scanner ss = new Scanner(new File("experiment//Exp_" + exp
						+ "//p_" + page_id + "_" + num
						+ "//likes_data//id_number.txt"));
				st = ss.nextLine();
				ss.close();
				while (in.hasNext()) {
					if (st.equals(in.nextLine()))
						break;
				}
				bb = true;
			}

			if (bb) {
				do {
					if (st != null) {
						id_number = st;
						st = null;
					} else
						id_number = in.nextLine();
					like_dealer(id_number, "experiment//Exp_" + exp + "//p_"
							+ page_id + "_" + num);
				} while (in.hasNext());
			}
			fid.delete();
			in.close();

		} catch (NoSuchElementException no) {
			fid.delete();
		} catch (Exception e) {
			try {
				Formatter fr = new Formatter("experiment//Exp_" + exp + "//p_"
						+ page_id + "_" + num + "//likes_data//id_number.txt");
				fr.format("%s", id_number);
				fr.close();
			} catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}
		}
	}

	private static void like_dealer(String post_id, String file_path)
			throws Exception {
		new File(file_path + "//likes_data").mkdir();
		String next = null;
		String after = null;
		FileWriter fw = null;
		try {
			String fields_string = make_fields_string("id");// ,"name");
			JsonObject one_like_page = check_existence_and_fetch(file_path
					+ "//likes_data//next_likes.txt", post_id + "/likes",
					fields_string);
			fw = new FileWriter(file_path + "//likes_data//user_" + post_id
					+ ".txt", true);
			boolean b = true;
			do {

				if (one_like_page.has("paging")
						&& one_like_page.getJsonObject("paging").has("next")) {
					next = one_like_page.getJsonObject("paging").get("next")
							.toString();
					// after =get_dash(next,"after=");
					after = one_like_page.getJsonObject("paging")
							.getJsonObject("cursors").get("after").toString();
					// System.out.println(next+"\n\nafter "+after);
				} else
					b = false;
				StringBuilder sb = new StringBuilder();
				recursive(one_like_page, fw, null, "", sb);
				if (after != null) {
					one_like_page = fb.fetchObject(post_id + "/likes",
							JsonObject.class, Parameter.with("limit", 1000),
							Parameter.with("fields", fields_string),
							Parameter.with("after", after));
					// after=null;
				}

			} while (one_like_page.has("paging") && b);
			new File(file_path + "//likes_data//next_likes.txt").delete();
		} catch (Exception f) {
			System.out
					.println("Network Error OR FB server is down...Try again later ");
			// f.printStackTrace();
			try {
				if (after != null) {
					Formatter ff = new Formatter(file_path
							+ "//likes_data//next_likes.txt");
					ff.format("%s", after);
					ff.close();
				}
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			throw new Exception();
		} finally {
			if (fw != null)
				try {
					fw.close();

				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

	}

	public static void comment_dealer(String post_id, String file_path)
			throws Exception {
		new File(file_path + "//comments_data").mkdir();
		String next = null;
		String after = null;
		String order = null;
		FileWriter fw = null;
		FileWriter fw2 = null;
		try {
			String fields_string = make_fields_string("id", "like_count",
					"message", "from");// ,"attachment","message_tags");
			JsonObject one_comment_page = check_existence_and_fetch(file_path
					+ "//comments_data//next_comments.txt", post_id
					+ "/comments", fields_string);
			fw = new FileWriter(file_path + "//comments_data//" + post_id
					+ ".txt", true);
			fw2 = new FileWriter(file_path + "//comments_data//user_" + post_id
					+ ".txt", true);
			boolean b = true;
			do {

				if (one_comment_page.has("paging")
						&& one_comment_page.getJsonObject("paging").has("next")) {
					next = one_comment_page.getJsonObject("paging").get("next")
							.toString();

					after = one_comment_page.getJsonObject("paging")
							.getJsonObject("cursors").get("after").toString();
					order = get_dash(next, "order=");
				} else
					b = false;
				StringBuilder sb = new StringBuilder();
				recursive(one_comment_page, fw, fw2, "", sb);

				if (after != null) {
					one_comment_page = fb.fetchObject(post_id + "/comments",
							JsonObject.class, Parameter.with("limit", 1000),
							Parameter.with("order", "reverse_chronological"),
							Parameter.with("fields", fields_string),
							Parameter.with("after", after),
							Parameter.with("order", order));

				}

			} while (one_comment_page.has("paging") && b);
			new File(file_path + "//comments_data//next_comments.txt").delete();
		} catch (Exception f) {
			System.out.println("Network Error...Try again later (comment)");
			f.printStackTrace();
			try {
				if (after != null) {
					Formatter ff = new Formatter(file_path
							+ "//comments_data//next_comments.txt");
					ff.format("%s\n%s", after, order);
					ff.close();
				}
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			throw new Exception();
		} finally {
			if (fw != null)
				try {
					fw.close();
					fw2.close();
					System.out.println("in comment finally");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

	}

	public static void check_work() {
		File fi = new File("experiment");
		int counter = 0;
		if (fi.exists())
			counter = fi.list(new FilenameFilter() {
				public boolean accept(File directory, String fileName) {
					return fileName.startsWith("Exp_")
							&& fileName.endsWith(".csv");
				}
			}).length;

		for (short j = 1; j <= counter; j++) {
			String[][] s = loadcsv.loadfile("experiment//Exp_" + j
					+ "//pages.csv");
			for (short i = 2; i < s.length; i++) {
				 check_page_work(s[i][0], i - 1, j);
				//check_comment_work(s[i][0], i - 1, j);
				//check_like_work(s[i][0], i - 1, j);
			}
		}

	}

	private static void check_comment_work(String page_id, int num, short exp) {
		System.out.println("\n\nCollecting Comments data for page:" + page_id);
		String id_number = "";
		File fid = null;
		try {
			Scanner in = new Scanner(new File("experiment//Exp_" + exp + "//p_"
					+ page_id + "_" + num + "//post_ids.txt"));
			boolean bb = !new File("experiment//Exp_" + exp + "//p_" + page_id
					+ "_" + num + "//comments_data").exists();
			fid = new File("experiment//Exp_" + exp + "//p_" + page_id + "_"
					+ num + "//comments_data//id_number.txt");
			String st = null;
			if (fid.exists()) {

				Scanner inn = new Scanner(new File("experiment//Exp_" + exp
						+ "//p_" + page_id + "_" + num
						+ "//comments_data//id_number.txt"));
				st = inn.nextLine();
				inn.close();
				bb = true;
			}
			if (bb) {
				do {
					if (st != null) {
						id_number = st;
						st = null;
					} else {
						id_number = in.nextLine();
					}
					int err = 0;
					while (err == 0) {
						try {
							comment_dealer(id_number, "experiment//Exp_" + exp
									+ "//p_" + page_id + "_" + num);
						} catch (Exception e) {
							e.printStackTrace();
							err = 0;
							for(int ii =0;ii<60;ii++){
								Thread.sleep(1000);
								System.out.println("waiting:"+ii);
							}
							continue;
						}
						err = 1;
					}
				} while (in.hasNext());
			}
			fid.delete();
			in.close();
		} catch (Exception e) {
			try {
				Formatter fr = new Formatter("experiment//Exp_" + exp + "//p_"
						+ page_id + "_" + num
						+ "//comments_data//id_number.txt");
				fr.format("%s", id_number);
				fr.close();
			} catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}
		}
	}

	private static void check_page_work(String page_id, int num, short exp) {
		System.out.println("\n\nCollecting posts data for page:" + page_id);
		File f = new File("experiment//Exp_" + exp + "//p_" + page_id + "_"
				+ num);
		if (!f.isDirectory())
			f.mkdir();
		do_all(page_id, num, exp, "id", "created_time",
				"likes.summary(true).limit(0)", "shares",
				"comments.summary(true).limit(0)", "message", "caption",
				"description", "message_tags", "story");// ,"with_tags");
	}

}
