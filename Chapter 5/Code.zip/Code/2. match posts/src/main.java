public class main {
	public static void main(String args[]) {
		String ds_posts = "FXM_posts";
		String[][] movies = loadcsv.loadfile("movies_new.csv");
		String posts_path = "D:\\CODE\\ANALYSIS-2\\0. get posts\\FB-FXM\\Exp_1\\p_100280026258_1\\post_message";
 		String[][] movies_posts = moviesposts.find(movies, posts_path);
		writecsv.write(ds_posts, movies_posts, 0, 0);
	}
}
