import java.io.*;

public class moviesposts {
	public static String[][] find(String[][] movies, String path) {
		multill retlist = new multill(3);
		int total_movies = movies.length;
		for (int i = 0; i < total_movies; i++) {
			String[] posts = searchinfilesandgetlist(path, movies[i][1]);
			if (posts != null) {
				System.out.println(i + "::" + posts.length);
				int posts_len = posts.length;
				for (int j = 0; j < posts_len; j++) {
					String[] temp = new String[3];
					temp[0] = movies[i][0];
					temp[1] = movies[i][1];
					temp[2] = posts[j];
					retlist.add(temp);
				}
			}
		}
		return retlist.getstringarray();
	}

	private static boolean splitmatch(String msg, String str) {
		boolean ret = true;
		str = str.trim();
		//str = "'" + str + "'";
		String[] spl = str.split(" ");
		int counter = 0;
		for (int i = 0; i < spl.length; i++) {
			if (msg.contains(spl[i])) {
				counter++;
			} else {
				return false;
			}
		}
		if (spl.length == counter) {
			return true;
		} else {
			return false;
		}
	}

	private static String[] searchinfilesandgetlist(String folderPath,
			String searchString) {
		try {
			String[] filelist = null;
			singlell ll = new singlell();
			File folder = new File(folderPath);

			if (folder.isDirectory()) {
				for (File file : folder.listFiles()) {
					if (!file.isDirectory()) {
						BufferedReader br = new BufferedReader(new FileReader(
								file));
						String content = "";
						try {
							StringBuilder sb = new StringBuilder();
							String line = br.readLine();

							while (line != null) {
								sb.append(line);
								sb.append(System.lineSeparator());
								line = br.readLine();
							}
							content = sb.toString();

						} finally {
							br.close();
						}
						if (splitmatch(content, searchString)) {
							System.out.println("File " + file.getName()
									+ " contains searchString " + searchString
									+ "!");
							String tmp = file.toString();
							String[] spl = tmp.split("\\\\");
							tmp = spl[spl.length - 1];
							spl = tmp.split("\\.");
							ll.add(spl[0]);
							//file.delete();
						}

					}
				}
			} else {
				System.out.println("Not a Directory!");
			}
			filelist = ll.getstringarray();
			return filelist;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
}
