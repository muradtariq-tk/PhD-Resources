import java.util.LinkedList;
import java.util.List;

public class multill {
	static List<String[]> s = null;
	static int limit = 0;

	public multill(int l) {
		limit = l;
		s = new LinkedList<String[]>();
	}

	public static void add(String[] inp) {
		if (inp.length == limit) {
			s.add(inp);
		}
	}

	public String[][] getstringarray() {
		int lllength = s.size();
		String[][] ret = new String[lllength][limit];
		for (int i = 0; i < lllength; i++) {
			String[] tmp = s.get(i);
			for(int j=0;j<limit;j++){
				ret[i][j]=tmp[j];
			}
		}
		return ret;
	}
}
