import java.util.LinkedList;
import java.util.List;


public class singlell {
	static List<String> s = null;
	
	public singlell(){
		s=new LinkedList<>();
	}
	
	public static void add(String inp){
		s.add(inp);
	}
	
	public String[] getstringarray(){
		int lllength = s.size();
		String[] ret = new String[lllength];
		for(int i = 0;i<lllength;i++)
		{
			String tmp = s.get(i);
			ret[i] =tmp;
		}
		return ret;
	}
}
