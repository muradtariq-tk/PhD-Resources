import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

import org.json.JSONArray;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

public class main {
	static String acc = "";
	static String[][] posts = null;
	static List<String[]> ll = new LinkedList<>();
	static String[][] sll = null;
	static String main_i = "1";

	public static void main(String[] args) {
		setaccesstokes();
		posts = loadcsv.loadfile("FXM_posts.csv");
		for (int i = 0; i < posts.length; i++) {
			try {
				if (fileexists(posts[i][0] + ".csv")) {
					System.out.println(posts[i][0] + ".csv :: FILE EXISTS");
					continue;
				}
				System.out.print(i + ":");
				ll = new LinkedList<>();
				sll = null;
				filllistwithcomments(posts[i][0]);
				convertll2sll();
				if (sll != null) {
					writecsv.writegeneric(posts[i][0] + ".csv", sll);
					System.out.println(posts[i][0] + ".csv :: created");
				} else {
					System.out.println(posts[i][0] + ".csv :: No record found");
				}
			} catch (Exception e) {
				System.out.println("############## -EXCEPTION- ##############");
				setaccesstokes();
				if (main_i.contains("-1")) {
					i = i;
					main_i = "1";
				} else if (main_i.contains("+1")) {
					convertll2sll();
					if (sll != null) {
						writecsv.writegeneric(posts[i][0] + ".csv", sll);
						System.out.println(posts[i][0] + ".csv :: created");
						setaccesstokes();
					} else {
						System.out.println(posts[i][0] + ".csv :: No record found");
					}
				} else {
					i = i - 1;
				}
			}
		}

	}

	public static boolean fileexists(String path) {
		File f = new File(path);
		if (f.exists() && !f.isDirectory()) {
			return true;
		}
		return false;
	}

	public static void filllistwithcomments(String id) throws IOException {
		String url = "https://graph.facebook.com/v2.10/"
				+ id
				+ "?access_token="
				+ acc
				+ "&debug=all&fields=comments.limit(1000)&format=json&method=get&pretty=0&suppress_http_code=1";
		try {

			Document doc = Jsoup
					.connect(url)
					.ignoreContentType(true)
					.userAgent(
							"Mozilla/5.0 (Windows; U; WindowsNT 5.1; en-US; rv1.8.1.6) Gecko/20070725 Firefox/2.0.0.6")
					.referrer("http://www.facebook.com").get();
			System.out.println(url);
			JSONObject obj = new JSONObject(doc.text());

			filljson(obj, "start");
			url = getnextpage(obj, "start");
			// obj.getJSONObject("likes").getJSONObject("paging").has("next")
			while (url != null) {
				System.out.println(url);
				doc = Jsoup.connect(url).ignoreContentType(true).get();
				obj = new JSONObject(doc.text());
				filljson(obj, "followed");
				url = getnextpage(obj, "followed");
			}

			// String pageName =
			// obj.getJSONObject("likes").getString("pageName");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		}
	}

	public static String getnextpage(JSONObject obj, String place) {
		JSONArray arr = null;
		try {
			if (place.contains("start")) {
				if (obj.getJSONObject("comments").getJSONObject("paging")
						.has("next")) {
					return obj.getJSONObject("comments")
							.getJSONObject("paging").getString("next");
				}
			}
			if (place.contains("followed")) {
				if (obj.getJSONObject("paging").has("next")) {
					return obj.getJSONObject("paging").getString("next");
				}
			}
		} catch (Exception e) {
			return null;
		}
		return null;
	}

	public static void filljson(JSONObject obj, String place) {
		JSONArray arr = null;
		try {
			if (place.contains("start")) {
				arr = obj.getJSONObject("comments").getJSONArray("data");
			} else {
				arr = obj.getJSONArray("data");
			}
		} catch (Exception e) {
			return;
		}
		for (int i = 0; i < arr.length(); i++) {
			String lid = arr.getJSONObject(i).getJSONObject("from")
					.getString("id");
			String name = "";
			try {
				name = arr.getJSONObject(i).getJSONObject("from")
						.getString("name");
			} catch (Exception e) {
			}
			String message = arr.getJSONObject(i).getString("message");
			message = message.trim();
			try {
				message = java.net.URLEncoder.encode(message, "UTF-8");
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String[] temp = new String[3];
			temp[0] = lid;
			temp[1] = name;
			temp[2] = message;
			ll.add(temp);
		}
	}

	public static void setaccesstokes() {
		Scanner reader = new Scanner(System.in); // Reading from System.in
		System.out.println("Enter Access Token:");
		String inp = "";
		inp = reader.next();
		if (inp.length() < 4 && inp.contains("-1")) {
			main_i = "-1";
		}
		if (inp.length() < 4 && inp.contains("+1")) {
			main_i = "+1";
		}
		acc = inp;
		acc = acc.trim();
	}

	public static void convertll2sll() {
		if (ll.size() >= 1) {
			sll = new String[ll.size()][3];
			for (int i = 0; i < ll.size(); i++) {
				String[] temp = ll.get(i);
				sll[i][0] = temp[0];
				sll[i][1] = temp[1];
				sll[i][2] = temp[2];

			}
		}
	}

}
