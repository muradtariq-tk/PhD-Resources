import java.io.UnsupportedEncodingException;
import java.util.LinkedList;
import java.util.List;

public class main {
	static List<String[]> ll = new LinkedList<>();
	static String[][] sll = null;

	public static void main(String[] args) {
		String dir = "D:\\CODE\\ANALYSIS-2\\2. getLikesFromPosts\\FXM-likes";
		String[][] mcsv = loadcsv.loadfile("FXM_posts.csv");
		for (int i = 0; i < mcsv.length; i++) {
			ll = new LinkedList<>();
			sll = null;
			String[][] fd = null;
			try {
				fd = loadcsv.loadfile(dir + "\\" + mcsv[i][2]
						+ ".csv");
			} catch (Exception e) {
				e.printStackTrace();
				continue;
			}
			System.out.println(fd.length);
			for (int j = 0; j < fd.length; j++) {

				String[] temp = new String[3];
				temp[0] = mcsv[i][0];
				temp[1] = mcsv[i][2];
				temp[2] = fd[j][0];
				
				ll.add(temp);
			}
			savesll(mcsv[i][0] + "-" + mcsv[i][2]);
		}
	}

	public static void savesll(String filename) {
		sll = new String[ll.size()][4];
		for (int i = 0; i < ll.size(); i++) {
			String[] temp = ll.get(i);
			sll[i][0] = temp[0];
			sll[i][1] = temp[1];
			sll[i][2] = temp[2];
		}
		writecsv.writegeneric("likes\\"+filename + ".csv", sll);
	}
}
