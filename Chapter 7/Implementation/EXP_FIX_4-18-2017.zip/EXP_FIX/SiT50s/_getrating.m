function [ valx] = getrating( mat,row,index)
rating = 0;
valx = 0 ;
val = 0;
lgv=0;
smv=0;
totalvalue = 0;
h=0;
if row(1,index)==0
    val = 0;
else
    col = mat(:,index);
    [h,htmp] = size(col);
    found = 0;
    for i =1:1:h
        val = val + col(i,1);
    end

    
    rating = val/h;
    val =0;
end
    if rating > 2.5
        val = 5;
    elseif rating >0 && rating<=2.5
        val = 2.5;
    end

valx = val;
end

