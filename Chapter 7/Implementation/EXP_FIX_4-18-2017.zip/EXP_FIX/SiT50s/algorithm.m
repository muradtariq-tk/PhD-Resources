function [ retmat ] = algorithm( mat,row,rankrow)
indexranked=getrankedindex(row,rankrow);
[x,y] = size(indexranked);

currentmatrix = [];
prevmatrix = [];
updatedmatrix = [];
updatedprevmatrix = [];

for i = 1:1:x
    index = indexranked(i);
    val = row(indexranked(i));
    currentmatrix = slicematrix(mat,index,val);
    updatedmatrix = findcommonrows(currentmatrix,prevmatrix);
    [xx,yy]= size(updatedmatrix);
    if xx==0
        retmat = updatedprevmatrix;
        break;
    else
        updatedprevmatrix = updatedmatrix;
    end
    prevmatrix = updatedmatrix;
    %if(x>3)
    %    break
    %end
end
retmat = updatedprevmatrix;
end

