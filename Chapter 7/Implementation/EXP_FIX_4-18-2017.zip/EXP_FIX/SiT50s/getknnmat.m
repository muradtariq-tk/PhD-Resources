function [ retmat ] = getknnmat( testrow,matrix,testing,N )
for i = 1:1:N
    rowx= popularitytraversal(testrow,matrix,testing);
    A = mfind(matrix,rowx);
    matrix(A,:)=[];
    relatedrows(i,:)=rowx;
end
retmat =relatedrows;
end

