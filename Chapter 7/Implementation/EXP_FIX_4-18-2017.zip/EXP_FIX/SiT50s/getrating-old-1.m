function [ valx] = getrating( mat,row,index)
%rowx=row;
sumx=0;
[xxx,yyy]=size(mat);
for i=1:1:xxx
sumx=sumx+mat(i,index);
end
ret = sumx/xxx;
valx=ret;