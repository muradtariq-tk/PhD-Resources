function [ valx] = getrating( mat,row,index)
valx = 0 ;
val = 0;
lgv=0;
smv=0;
totalvalue = 0;
if row(1,index)==0
    val = 0;
else
    col = mat(:,index);
    h = size(col);
    found = 0;
    for i =1:1:h
        if col(i,:)>2.5
            found = 1;
            break;
        end
    end
    if found == 1
        val = 5;
    else
        val = 2.5;
    end
end
valx = val;
end

