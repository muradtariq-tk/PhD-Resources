function [ rp,rr,rf,rs,rm ] = main(r,k,N)
% k represents averaging per iteration
% N represents nearest neighbours
%-------------------------------------------------------------------

load('MT.mat');
MT=MT.mt;
f1=exist('_testing.mat');
f2=exist('_training.mat');
f3=exist('_mappedusers.mat');

if f1==0 || f2==0 || f3==0 

%--[generating training and test matrix]----------------------------

%-[these lines are temporary commented ]

%percent = 50;
%[mpa_testing,mpa_training] = split_test_training(percent,mpa); 

%-----

load('_testing.mat');
load('_training.mat');

%--[profile mapping from source to target users]--------------------
% profilematch switch 
% s = 1 skip assigned profile
% S = 2 no skipping allowed
s=1;
%mappedusers = mappingalgorithm_correlation(training,MT,s);
%mappedusers = mappingalgorithm_popularitytraversal(training,MT);
mappedusers = training;
%--[applying filter generated from training users]------------------
%row_filter = trainingfunction(training,MT);

save('_mappedusers.mat','mappedusers');
else
load('_testing.mat');
load('_training.mat');
load('_mappedusers.mat');
    
end

%%mappedusers_new_1 =applyfilter(row_filter,mappedusers,0);
mappedusers_new_1 = mappedusers;
psc = 0;
rsc=0;
fsc = 0;
rss=0;
f=0;
maej = 0 ;
maer = 0;
rscore = 0;
rf=0;
rp=0;
rr=0;
rs=0;
for i=1:1:r
    for j = 1:1:k
        j
        [xi,yi] = size(testing);
        rowindex = ceil(rand()*xi);
        testrow = testing(rowindex,:);
        %%testrow_new_1 = applyfilter(row_filter,testrow,0);
        testrow_new_1 = testrow;
        [ps,era,mra,rsx,mae]= applyalgorithm(testrow_new_1,mappedusers_new_1,testing,N);

        maej = maej+mae;
        psc = psc + ps;
        rsc = rsc + era;
        fsc = fsc + mra;
        rss = rss + rsx;
        if isnan(fsc)==1
            fsc = 0;
        end
        f=f+fsc;
        %disp(i);
    end
    maej = maej /k;
    psc = psc / k;
    rsc = rsc / k;
    rss = rss / k;
    f=f/k;
    rp=rp+psc;
    rr=rr+rsc;
    rf=rf+f;
    rs=rs+rss;
    maer = maer+maej;
    psc = 0;
    rsc = 0;
    maej = 0;
end
rp=rp/r;
rr=rr/r;
rf=rf/r;
rs=rs/r;
rm =maer/r;
end