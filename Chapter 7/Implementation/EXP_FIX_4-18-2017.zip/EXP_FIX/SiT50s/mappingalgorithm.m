function [ mappedmatrix] = mappingalgorithm( matrix_target,matrix_source)
[x,y] = size(matrix_target);
% profilematch switch 
% s = 1 skip assigned profile
% S = 2 no skipping allowed

for i = 1:1:x
    mappedmatrix(i,:) = popularitytraversal(matrix_target(i,:),matrix_source,matrix_target);
    %disp(i);
end


end

