function [ mappedmatrix] = mappingalgorithm_correlation( matrix_target,matrix_source,s )

% profilematch switch 
% s = 1 skip assigned profile
% S = 2 no skipping allowed

profilemap=[];

[xfb,yfb]=size(matrix_source);
[xpa,ypa]=size(matrix_target);

for i =1:1:xpa
        profilemap(i,1) = i;
        profilemap(i,2) = 0;
        [profilemap(i,2),profilemap(i,3),profilemap(i,4)] = profilematch(matrix_target((i),:),matrix_source,profilemap,s);
        disp(profilemap(i,1))
end

[xx,yy] = size(profilemap);
for i = 1:1:xx
    rowindex = profilemap(i,2);
    mappedmatrix(i,:) = matrix_source(rowindex,:);
end


end

