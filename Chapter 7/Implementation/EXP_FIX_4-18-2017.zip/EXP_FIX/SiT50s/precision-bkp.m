function [ score ] = precision( row1,row2)
row1 = row1';
row2 = row2';
row1p = [];
row2p = [];
tp = 0;
tn=0;
fp = 0 ;
fn=0;
[x,y] = size(row1);
for i = 1:1:x
    row1p(i)=0;
    row2p(i)=0;
    row1n(i)=0;
    row2n(i)=0;
    if row1(i)>2.5
        row1p(i) = 1;
    end
    if row2(i)>2.5
        row2p(i) = 1;
    end
        
    if row1p(i)==row2p(i) && row1p(i) ==1
        tp=tp+1;
    end
    if row1p(i)==0 && row2p(i)==1
        fp=fp+1;
    end
    
    if row1(i)<=2.5 && row1(i)~=0
        row1n(i) = 1;
    end
    if row2(i)<=2.5 && row2(i)~=0
        row2n(i) = 1;
    end
    if row1n(i)==row2n(i) && row1n(i) ==1
        tn=tn+1;
    end
    if row1n(i)==0 && row2n(i)==1
        fn=fn+1;
    end
    
    
    
end
if tp == fp && fp == 0
    fp = 1;
end
pscore = (tp)/(tp+fp);

score = (pscore);
