function [ retmat ] = slicematrix( mat,index,val)
ret = []; 
[x,y] = size(mat);
counter = 1;
if val <= 2.5
    for i = 1:1:x
        if mat(i,index)<= 2.5
            ret(counter,:)=mat(i,:);
            counter = counter +1;
        end
    end
end

counter = 1;
if val > 2.5
    for i = 1:1:x
       if mat(i,index)> 2.5
            ret(counter,:)=mat(i,:);
            counter = counter +1;
       end
    end
end

retmat = ret;
end

