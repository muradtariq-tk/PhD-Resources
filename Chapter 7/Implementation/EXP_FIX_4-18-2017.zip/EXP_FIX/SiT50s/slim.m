function [ slimretx ] = slim( mpa, sumth,counth,atleastcount)
sr = sum(mpa');
sr = sr';
slim = [];
[x,y] =size(mpa);
count = 1;
for i = 1:1:x
    if sr(i)>=sumth
        slim(count,:)=mpa(i,:);
        count=count+1;
    end
end
count = 1;
[x,y] = size(slim);
slimret=[];
for i = 1:1:x
    row = slim(i,:);
    [xx,yy] = size(find(row));
    if yy>=counth
        slimret(count,:)=slim(i,:);
        count=count+1;
    end
end


count = 1;
[x,y] = size(slimret);
slimret2=[];
for i = 1:1:x
    row = slimret(i,:);
    [xx,yy] = (find(row));
    for j = 1:1:size(xx)
        if row(xx(j),yy(j))>=atleastcount
        slimret2(count,:)=row;
        count=count+1;
        continue;
    end
    end
end

slimretx = slimret2;

end





