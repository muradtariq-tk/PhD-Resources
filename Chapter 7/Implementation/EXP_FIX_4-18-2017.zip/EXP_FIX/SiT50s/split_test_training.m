function [ test,training ] = split_test_training( percent,matrix)
matrix = slim(matrix,10,2,2.51);
[x,y] = size(matrix);
limit = ceil(x*(percent/100));

resized_matrix = matrix;
temptraining = [];
for i=1:1:limit
    [nx,ny]=size(resized_matrix);
    row_to_extract = ceil(rand(1)*nx);
    temptraining(i,:)=resized_matrix(row_to_extract,:);
    resized_matrix  = resized_matrix(setdiff(1:size(resized_matrix,1),row_to_extract),:);
end
test = resized_matrix;
training = temptraining;

