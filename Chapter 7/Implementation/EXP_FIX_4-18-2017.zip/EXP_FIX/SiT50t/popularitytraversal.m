function [ retrow ] = popularitytraversal( row,mat,testing)
retry = 1;
while retry ~= 0
rankm = sum(mat);
rank1 = sum(testing);
if length(rank1)==1
rank1=testing;
end
rankx=rank1+rankm;
rkrow = rankrow(rank1,1);
rkrowp = rankrow(rank1,0);
mat_1 = algorithm(mat,row,rkrowp);

[x,y]= size(mat_1);
dist = [];
if x==0
    retry = 0;
    mat_1 = mat;
    %disp('no match found');
else
    retry = 0;
end
res = [];
maxc=1;
max = sxycov(row',mat_1(1,:)');
for i=1:1:x
    res(i,1)=i;
    res(i,2)=sxycor(row',mat_1(i,:)');
    if res(i,2)>max
        max=res(i,2);
        maxc=res(i,1);
    end
end

retrow = mat_1(maxc,:);
end

end

