function [ testing,training ] = split_test_training(percent,matrix)
testing=[];
training=[];
[xx,yy] = size(matrix);
totalrows = ceil(xx*percent);
A = [1:1:xx];
idx=randperm(numel(A));
 training_rows_index = A(idx(1:(ceil(xx*percent))));
test_rows_index= A(idx((ceil(xx*percent)+1:xx)));

[x,y] = size(test_rows_index);
for i = 1:1:y
    training(i,:) = matrix(test_rows_index(i),:);
end

[x,y] = size(training_rows_index);
for i = 1:1:y
    testing(i,:) = matrix(training_rows_index(i),:);
end
