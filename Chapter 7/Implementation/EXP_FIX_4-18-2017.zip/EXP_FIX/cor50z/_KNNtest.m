function [ ret ] = KNNtest(N)
load('mfb.mat');
load('mpa.mat');
% profilematch switch 
% s = 1 skip assigned profile
% S = 2 no skipping allowed
s = 1;
percent = 25;
[mpa_testing,mpa_training] = split_test_training(percent,mpa); 
row_filter = trainingfunction(mpa_training,mfb);

disp('test and training set created');
[x,y] = size(mfb);

[xfb,yfb]=size(mfb);
[xpa,ypa]=size(mpa_testing);

%for i =1:1:xfb
%        profilemap(i,1) = i;
%        profilemap(i,2) = 0;
%        [profilemap(i,2),profilemap(i,3),profilemap(i,4)] = profilematch(mfb((xfb+1-i),:),mpa_testing,profilemap,s);
%        disp(profilemap(i,1))
%end


%pn = profilemap;
score = 0;
users = 1;
for i = 1:1:users
    %[mxx,mxy] = max(pn(:,4));
    %pn_respective_index = pn(mxy,1);
    %mfbindex = pn_respective_index;
    %mpa_testing_index = profilemap(mxy,2);
    %profilemap = removerow(profilemap,mxy);
    randomrow = ceil(xpa*rand(1));
    row = mpa_testing(randomrow,:);
    %row_high_cor_fb = mfb(mfbindex,:);
    resultrow = applyalgorithm(row,row_filter,mfb,N);
    resultrow = resultrow';
    %pn = removerow(pn,mxy);
    pscore = precision(resultrow(1,:),resultrow(2,:));
    score = score + pscore;
    disp(i);
end
score = score / users;
ret=resultrow';
ret = score;
disp(score)
end

