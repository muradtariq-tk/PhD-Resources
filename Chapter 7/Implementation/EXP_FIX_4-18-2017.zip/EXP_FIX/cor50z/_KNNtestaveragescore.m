function [ averagescore ] = KNNtestaveragescore( )
score = 0;
times = 20;
N=1;
for i = 1:1:times
  score = score+KNNtest(N);
end

averagescore = score/times;
disp(averagescore);

