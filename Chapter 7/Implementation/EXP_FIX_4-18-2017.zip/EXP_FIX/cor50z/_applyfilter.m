function [ retmatx] = applyfilter(row,mat,c)
%c = 1 strict meaning filter 0 not equal to 2.5
[x,y] = size(mat);
retmat = [];

if c == 1
for i = 1:1:x
    for j=1:1:y
        if row(1,j) ~=0
            if mat(i,j)>2.5
            retmat(i,j) = 5;
            elseif mat(i,j)>0 && mat(i,j)<=2.5
                retmat(i,j)=2.5;
            else
                retmat(i,j)=0;
            end
        
        else
            retmat(i,j)=0;
        end
    end
    
   
end
 retmatx=retmat;
end


if c == 0
for i = 1:1:x
    for j=1:1:y
        if row(1,j) ~=0
            if mat(i,j)>2.5
            retmat(i,j) = 5;
            elseif mat(i,j)<=2.5
                retmat(i,j)=2.5;
            else
                retmat(i,j)=0;
            end
        
        else
            retmat(i,j)=0;
        end
    end
    
   
end
 retmatx=retmat;
end


end