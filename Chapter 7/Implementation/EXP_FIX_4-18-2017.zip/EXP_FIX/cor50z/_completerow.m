function [ out ] = completerow( row1,mpaindex,mfb,mpa,N)
row = row1;
res = [];
[x,y]=size(row);
for i = 1:1:y
    res(i,1)=row(i);
    res(i,2)=knnc(i,row,mpa,N);
end
out = res;
end