function [ cr] = corelation(A,B)
An = bsxfun(@minus,A,mean(A,1));
Bn = bsxfun(@minus,B,mean(B,1));

An = bsxfun(@times,An,1./sqrt(sum(An.^2,1)));
Bn = bsxfun(@times,Bn,1./sqrt(sum(Bn.^2,1)));

cr = sum(An.*Bn,1);

end

