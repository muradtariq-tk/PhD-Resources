function [mat] = differencescore(inp1,inp2)
[x,y]=size(inp1);
d=0;
t=0;
for i = 1:1:y
    if inp1(1,i)~=0
        d=d+abs(inp1(1,i)-inp2(1,i));
        t=t+1;
    end
end
mat = d/t;
end
