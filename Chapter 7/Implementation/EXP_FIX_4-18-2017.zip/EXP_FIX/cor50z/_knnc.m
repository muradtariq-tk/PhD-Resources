function [ ratingret ] = knnc(position,row,mat,k)
lookingfor = row(1,position);
[x,y]=size(mat);
mat_original = mat;
distance=[];
calc=0;

skippedrows = [];
relatedrows=[];

skip = 1;
cnt = 0;
for i =1:1:x
    for j =1:1:y
        calc = calc+(mat(i,j)-row(1,j))^2;
    end
    distance(i,:)=calc;
    calc = 0;
end

relateddistance=[];
for i = 1:1:k
    cnt=cnt+1;
    [minx , miny]=min(distance);
    relatedrows(cnt,:)=mat(miny,:);
    relateddistance(i,:)=[minx , miny];
    distance = distance(setdiff(1:size(distance,1),miny),:);
end

rating = 0 ;
res = 0;
for i = 1:1:k
    
    if relatedrows(i,position)>2.5
        res = res+1;
    end
end
if res >= (1)
    res = 5;
else
    res = 2.5;
end
ratingret = res;



