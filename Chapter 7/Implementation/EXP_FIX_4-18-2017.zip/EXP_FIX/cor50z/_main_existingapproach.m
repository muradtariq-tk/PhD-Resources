function [ rp,rr,rf,rm ] = main_existingapproach(r,k,N)
% k represents averaging per iteration
% N represents nearest neighbours
%-------------------------------------------------------------------
load('mpa.mat');
load('mfb.mat');
mpa = ma;
mfb = mb;

f1=exist('ea_mpa_testing.mat');
f2=exist('ea_mpa_training.mat');
f3=exist('ea_mappedusers.mat');
f4=exist('ea_row_filter.mat');

if f1==0 && f2==0 && f3==0 && f4==0

%--[generating training and test matrix]----------------------------
percent = 50;
[mpa_testing,mpa_training] = split_test_training(percent,mpa); 

%--[profile mapping from source to target users]--------------------
% profilematch switch 
% s = 1 skip assigned profile
% S = 2 no skipping allowed
s=1;
mappedusers = mappingalgorithm_correlation(mpa_training,mfb,s);

%--[applying filter generated from training users]------------------
row_filter = trainingfunction(mpa_training,mfb);

save('ea_mpa_testing.mat','mpa_testing');
save('ea_mpa_training.mat','mpa_training');
save('ea_mappedusers.mat','mappedusers');
save('ea_row_filter.mat','row_filter');
else
load('ea_mpa_testing.mat');
load('ea_mpa_training.mat');
load('ea_mappedusers.mat');
load('ea_row_filter.mat');
    
end

%mappedusers_new_1 =applyfilter(row_filter,mappedusers,0);
mappedusers_new_1 = mappedusers;
psc = 0;
rsc=0;
f=0;
maej = 0;
rscore = 0;
rf=0;
rp=0;
rr=0;
maer = 0;
for i=1:1:r
    for j = 1:1:k
        [xi,yi] = size(mpa_testing);
        rowindex = ceil(rand()*xi);
        testrow = mpa_testing(rowindex,:);
        %%testrow_new_1 = applyfilter(row_filter,testrow,0);
        testrow_new_1 = testrow;
        resultrows = applyalgorithm(testrow_new_1,mappedusers_new_1,N);
        resultrows = resultrows';
        [ps,rs,mae] = precision(resultrows(1,:),resultrows(2,:));
        maej = maej+mae;
        psc = psc + ps;
        rsc = rsc + rs;
        fsc = (2*(ps*rs)/(ps+rs));
        if isnan(fsc)==1
            fsc = 0;
        end
        f=f+fsc;
        disp(i);
    end
    maej = maej /k;
    psc = psc / k;
    rsc = rsc / k;
    f=f/k;
    rp=rp+psc;
    rr=rr+rsc;
    rf=rf+f;
    maer = maer+maej;
    psc = 0;
    rsc = 0;
    maej = 0;
end
rp=rp/r;
rr=rr/r;
rf=rf/r;
rm =maer/r;
end