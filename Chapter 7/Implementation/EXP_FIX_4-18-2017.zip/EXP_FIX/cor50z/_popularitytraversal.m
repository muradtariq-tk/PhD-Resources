function [ retrow ] = popularitytraversal( row,mat)
retry = 1;
while retry ~= 0
rank1 = sum(mat);
rkrow = rankrow(rank1,1);
rkrowp = rankrow(rank1,0);
mat_1 = algorithm(mat,row,rkrow);

[x,y]= size(mat_1);
dist = [];
if x==0
    retry = 0;
    mat_1 = mat
    [x,y]= size(mat_1);
    %[xx,yy] = size(mat(1,:));
    %retrow = ones(1,yy);
    %retrow = retrow.*2.5;
    %return;
    %continue;
else
    retry = 0;
end
for i=1:1:x
    r(1,:)=row;
    r(2,:)=mat_1(i,:);
    dist(i,1)=i;
    dist(i,2)=pdist(r);
end
dist
dist = sortrows(dist,2);

retrow = mat_1(dist(1,1),:);
end

end

