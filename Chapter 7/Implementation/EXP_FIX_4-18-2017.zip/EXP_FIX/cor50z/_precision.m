function [ps,rs,mae] = precision(row1,row2)
[r1srt,r2str]=short(row1,row2);
[xx,yy]= size(r1srt);

res = 0;
tp=0;
fp=0;
fn=0;
sum = 0;
for i = 1:1:yy
sum = sum +abs((r1srt(1,i)-r2str(1,i)));
    if r1srt(1,i)==r2str(1,i)
        res=res+1;
        tp=tp+1;
    else
        if r1srt(1,i)<r2str(1,i)
         fp=fp+1; 
        end
        if r1srt(1,i)>r2str(1,i)
            fn=fn+1;
        end
    end
end
mae = sum / yy;
pscore = (tp)/(tp+fp);
rscore = (tp)/(tp+fn);
ps = pscore;

    
rs = rscore;
if isnan(rs)==1
    rs=0;
end
if isnan(ps)==1
    ps=0;
end
end