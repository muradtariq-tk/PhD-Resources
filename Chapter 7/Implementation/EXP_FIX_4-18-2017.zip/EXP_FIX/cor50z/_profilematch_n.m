function [ user,retr,retrabs,sac ] = profilematch_n( inp1,inp2,inp3,s)
n = get_n(inp1',inp2(1,:)');
if n > 25
    ratio = 1;
else
    ratio = n/25;
end

pd =ratio * sxy(inp1',inp2(1,:)');
pdsxy = sxy(inp1',inp2(1,:)');
    retr= 0;
    retrabs = 0;
r=pd;
sac = r ;

rabs=abs(r);
user = 1;
val=r;
[x2,y2]=size(inp2);
[x3,y3]=size(inp3);
cont = 0;
inp3d = inp3(:,2)';
for i=1:1:x2
    
   n = get_n(inp1',inp2(i,:)');
if n > 25
    ratio = 1;
else
    ratio = n/25;
end

    
        if ~isempty(find(inp3d==i)) && s ==1 
            cont = 1;
            continue;
        else
            cont = 0;
        end
    if cont == 1
        continue
    end
    pd = ratio*sxy(inp1',inp2(i,:)');
    r =  pd;
    rabs= abs(r);
    if r>val
    user=i;
    val = rabs;
    retr= r;
    retrabs = rabs;
    sac = ratio;
    end
    
end
cont = 0;
end


