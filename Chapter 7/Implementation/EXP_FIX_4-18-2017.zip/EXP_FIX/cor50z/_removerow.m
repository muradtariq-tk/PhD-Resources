function [ retx ] = removerow(matrix,rowindex)
ret =  matrix(setdiff(1:size(matrix,1),rowindex),:);
retx=ret;
%UNTITLED12 Summary of this function goes here
%   Detailed explanation goes here


end

