rp = [];
rr = [];
rf = [];
mae = [];
for i = 1:1:20
[rp(i,1),rr(i,1),rf(i,1),mae(i,1)]=main_existingapproach(10,100,i);
end
disp('wait');