function [mat] = scale5(inp)
[x,y]=size(inp);
mat = zeros(x,y);
for i = 1:1:x
    for j = 1:1:y
        if inp(i,j) ~=0
            if inp(i,j)>2.5
                mat(i,j)=5;
            else
                mat(i,j)=2.5;
            end
        end
    end
end