function [ retx ] = trainingfunction(mat1,mat2)
[x,y] = size(mat1);
s = sum(mat1);
s2 = histeq(s);
ret =[];
gthalf = 0;
lthalf = 0;

for i=1:1:y
col = mat1(:,i);
for j = 1:1:x
    if col(j,:) <=2.5 && col(j,:) ~= 0
        lthalf =lthalf + 1;
    end
    if col(j,:) >2.5
        gthalf =gthalf + 1;
    end
end
if gthalf == 0 && lthalf==0
    ret(1,i)=0;
else
    ret(1,i)=gthalf/(gthalf+lthalf);
end
retx=ret;
end

