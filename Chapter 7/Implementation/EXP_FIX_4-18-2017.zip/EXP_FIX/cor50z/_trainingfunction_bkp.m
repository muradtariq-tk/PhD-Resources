function [ retx ] = trainingfunction(mat1,mat2)
[x,y] = size(mat1);
ret = [];
for i = 1 :1:y
    column = mat1(:,i);
    [r1,r2] = find(column);
    [r1x,r1y] = size(r1);
    if r1x == 0
        ret(i) = 0;
        continue
    end
    sum = 0 ;
    count = 0;
    for j = 1:1:r1x
        sum=sum+column(r1(j),1);
        count=count+1;
    end
    avg=sum/count;
    if avg>2.5
        ret(i) = 1;
    end
    if avg<2.5
        ret(i) = 0.5;
    end
end
retx=ret;
end

