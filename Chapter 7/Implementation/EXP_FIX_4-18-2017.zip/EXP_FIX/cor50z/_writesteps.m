function [] = writesteps(inp1,inp2)

h=[];
h(1,:)=inp1;
h(2,:)=inp2;

M=h;
dlmwrite('temp.txt',M);
end