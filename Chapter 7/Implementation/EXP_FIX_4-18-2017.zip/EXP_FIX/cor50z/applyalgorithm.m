function [ pscore,era,mra,rscore,mae ] = applyalgorithm(testrow,mat,N)
master_row = testrow;
till=10;
ps_ = 0;
rs_ = 0;
mae_= 0;
tpx=0;
tnx=0;
fpx=0;
fnx=0;
mae = 0;
counter = 0;
er = 0;
mr = 0;
for ii=1:1:till
testrow=master_row;
[xxx,yyy] = find(testrow<=5);
[xx,yy] = size(yyy);
loc = ceil(rand*yy);
loc = yyy(loc);
value_of_testrow = testrow(1,(loc));
testrow(1,loc) = 0;
row = testrow;
res = [];
[x,y]=size(row);
knnmat = getknnmat(testrow,mat,N);
[fx,fy] = find(row);
output=[];
rowshort=row;
knnshort=knnmat;
%[rowshort,knnshort] = short(row,knnmat);
[xx,yy]=size(fy);

%for i=1:1:yy
    output = getrating(knnmat,row,loc);
    er = er + extraratings(knnmat,row);
    mr = mr + mappedratings(knnmat,row);
    %rowval = row(fx(i),fy(i));
    [tp,tn,fp,fn] = prec(value_of_testrow,output);
    tpx=tpx+tp;
    tnx=tnx+tn;
    fpx=fpx+fp;
    fnx=fnx+fn;

    mae = mae+abs(value_of_testrow-output);
    
%end
end
mae = mae / till;
rscore = (tpx)/(tpx+fnx);
pscore = (tpx)/(till);
era = er/till;
mra = mr/till;
end