function [ pscore,rscore,mae ] = applyalgorithm( testrow,mat,N)
row = testrow;
res = [];
[x,y]=size(row);
knnmat = getknnmat(testrow,mat,N);
[fx,fy] = find(row);
output=[];
rowshort=row;
knnshort=knnmat;
%[rowshort,knnshort] = short(row,knnmat);
[xx,yy]=size(fy);
ps_ = 0;
rs_ = 0;
mae_= 0;
tpx=0;
tnx=0;
fpx=0;
fnx=0;
mae = 0;
for i=1:1:yy
    output = getrating(knnmat,row,fy(i));
    rowval = row(fx(i),fy(i));
    [tp,tn,fp,fn] = prec(rowval,output);
    
tpx=tpx+tp;
tnx=tnx+tn;
fpx=fpx+fp;
fnx=fnx+fn;
mae = mae+abs(output-rowval);
end
tpx=tpx;
tnx=tnx;
fpx=fpx;
fnx=fnx;
mae = mae / yy;
pscore = (tpx)/(tpx+fpx);
rscore = (tpx)/(tpx+fnx);
if isnan(rscore)==1
    rscore=0;
end
if isnan(pscore)==1
    pscore=0;
end
end