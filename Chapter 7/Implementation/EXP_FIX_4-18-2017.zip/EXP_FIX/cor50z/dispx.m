function [] = dispx (inp1,inp2,s)
inp2 = double(inp2);
fs = fspec(inp2,s);
if s == 1
    formatSpec = fs;
    fprintf(formatSpec,inp1,inp2);
end
if s == 2
    formatSpec = fs;
    %formatSpec = '[%2.2f \t :: %2.2f\t%2.2f\t%2.2f\t%2.2f ] \n';
    fprintf(formatSpec,inp1,inp2);   
end
