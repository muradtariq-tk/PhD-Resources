function [mat] = emptyratings (inp1,inp2)
[x,y]=size(inp1);
r=0;
for i = 1:1:y
    if inp1(1,y)==0
        if inp2(1,y)~=0
            r=r+1;
        end
    end
end
mat =r;
end
