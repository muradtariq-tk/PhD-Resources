function [ retmat] = findcommonrows(currentmatrix,prevmatrix)
[cmx,cmy] = size(currentmatrix);
[pmx,pmy] = size(prevmatrix);

if pmx ==0 
    retmat = currentmatrix;
    return;
end

if cmx ==0 
    retmat = prevmatrix;
    return;
end

if pmx ~=0 && cmx ~=0
retmat = intersect(currentmatrix,prevmatrix,'rows');
end

end

