function [ret] = fspec(inp1,sw)
[x,y] = size(inp1);
t=[];
for i = 1 :1:y
t = [t '%2.2f\t'];
end
if sw == 1
s = ['[%s \t :: ' t ' ] \n'];
else
s = ['[%2.2f \t :: ' t ' ] \n'];
end

ret = s;
