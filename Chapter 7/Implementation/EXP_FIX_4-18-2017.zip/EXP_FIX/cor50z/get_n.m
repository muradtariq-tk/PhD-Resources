function [ retn ] = get_n(inp1,inp2)

[i1] = find(inp1);
[i2] = find(inp2);

n = intersect(i1,i2);

[x,y] =size(n);

retn = x ; 


end

