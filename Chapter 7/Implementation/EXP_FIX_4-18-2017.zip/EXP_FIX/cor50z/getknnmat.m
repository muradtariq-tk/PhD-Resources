function [ retmat ] = getknnmat( testrow,matrix,N )
if N == 0
    retmat=matrix;
else
matrixnew =matrix;
[x,y]=size(matrix);

%for i = 1:1:x
%    matrixnew(i,:)=matrix(i,:).*filter;
%end

distance=[];
calc=0;
for i =1:1:x
    testrowshort = testrow;
    currentshort = matrixnew(i,:);
    %[testrowshort,currentshort]=short(testrow,matrixnew(i,:));
    distance(i,:)=sxy(testrowshort',currentshort');
    calc = 0;
end

cnt=0;
for i = 1:1:N
    cnt=cnt+1;
    [maxv , maxy]=max(distance);
    relatedrows(cnt,:)=matrixnew(maxy,:);
    distance([maxy],:)=[];
end
retmat =relatedrows;
end

end