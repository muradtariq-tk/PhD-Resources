function [ retmat ] = getrankedindex(row,rankrow)
% convention rank large value = high priority and small value = low
% priority

[xrow,yrow] = find(row);
[xrank,yrank]=find(rankrow);

m1 = [];
for i = 1:1:size(yrow')
    m1(i,2)=rankrow(yrow(i));
    m1(i,1)=yrow(i);
end
mx = sortrows(m1,-2);
retmat = mx;
end

