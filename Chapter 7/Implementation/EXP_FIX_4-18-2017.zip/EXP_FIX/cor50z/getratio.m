function [ val] = getratio(mat)
[xx,yy] = find(mat);
smv=0;
lgv=0;
xxx = size(xx);
for i = 1:1:size(xx)
    v = mat(xx(i),yy(i)) ;
    disp(v);
    if mat(xx(i),yy(i))<=2.5 && mat(xx(i),yy(i))>0
        smv = smv +1;
    end
    if mat(xx(i),yy(i))>2.5 
        lgv = lgv +1;
    end
end
val = lgv/(lgv+smv);
end