function [mr] = mappedratings( knn,row)
kn = mean(knn);
if(length(kn)==1)
    kn=knn;
end
rowshort = [];
[xx,yy]=find(row~=0);
rowr=size(xx');
knrat=0;
for i = 1:1:rowr
rs(1,i)=row(xx(i),yy(i));
if(kn(xx(i),yy(i))~=0)
knrat = knrat +1;
end
end
mr = (knrat*100) / rowr(1,1);
end