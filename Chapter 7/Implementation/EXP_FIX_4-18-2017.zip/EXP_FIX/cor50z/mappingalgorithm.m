function [mappedmatrix] = mappingalgorithm(matrix_target,matrix_source)
% profilematch switch 
% s = 1 skip assigned profile
% S = 2 no skipping allowed
s=1;
profilemap=[];
[xfb,yfb]=size(matrix_source);
[xpa,ypa]=size(matrix_target);
for i =1:1:xpa
        profilemap(i,1) = i;
        profilemap(i,2) = 0;
        [profilemap(i,2),profilemap(i,3),profilemap(i,4),profilemap(i,5)] = profilematch_sxy(matrix_target((i),:),matrix_source,profilemap,s);
%disp(i);
end

[xx,yy] = size(profilemap);
for i = 1:1:xx
    rowindex = profilemap(i,2);
    mappedmatrix(i,:) = matrix_source(rowindex,:);
end
end