function [tp,tn,fp,fn] = prec(element1,element2)
%
tp=0;
tn=0;
fp=0;
fn=0;
if(abs(element2-element1)<=2)
tp=1;
end
if(tp~=1 && element2>element1)
fn=1;
end
end