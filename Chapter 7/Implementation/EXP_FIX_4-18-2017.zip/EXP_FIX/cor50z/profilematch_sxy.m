function [ user,retr,retrabs,sac ] = profilematch_sxy( inp1,inp2,inp3,s)

pd = sxy(inp1',inp2(1,:)');
pdsxy = sxy(inp1',inp2(1,:)');

retr= 0;
    retrabs = 0;
r=pd;
sac = r ;

rabs=abs(r);
user = 1;
val=r;
[x2,y2]=size(inp2);
[x3,y3]=size(inp3);
cont = 0;
inp3d = inp3(:,2)';
for i=1:1:x2
    
        if ~isempty(find(inp3d==i)) && s ==1 
            cont = 1;
            continue;
        else
            cont = 0;
        end
    if cont == 1
        continue
    end
    pd = sxy(inp1',inp2(i,:)');
    if pd == 1
        writesteps(inp1',inp2(i,:)');
    end
    
    r =  pd;
    %dispx(pd,inp2(i,:),2);
    rabs= abs(r);
    if r>val
    user=i;
    val = rabs;
    retr= r;
    retrabs = rabs;
    sac = r;
    end
    
end
cont = 0;
end


