function [ retmat] = rankrow(row,s)
%s=1 then lowest rated item is at highest priority
%s=0 then lowest rated item is at lowest priority
srt = sort(row');
[x,y] = size(row);
retrow=[];
[b,n1,x1]=unique(srt,'first');
srt=b;
[xx,yy] = size(srt');
for i =1:1:y
    for j = 1:1:yy
        if row(1,i)==srt(j);
            retrow(1,i)=j;
    end
end


end
if s==0
retmat=retrow;
else
    mx = max(retrow);
    mn = min(retrow);
    t = [mn:1:mx];
    td = fliplr(t);
    t=t';
    td=td';
    
    [x,y]= size(retrow);
    [xx,yy] = size(t);
    for i=1:1:y
        v=retrow(i);
        retrow(i)=td(v);
    end
    retmat = retrow;
end
end
