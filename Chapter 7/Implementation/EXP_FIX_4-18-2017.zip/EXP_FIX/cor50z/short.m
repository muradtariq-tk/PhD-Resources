function [ rowshort,knnshort] = short( row,knn)
rowshort = [];
[xx,yy]=find(row);
for i = 1:1:size(xx')
rs(1,i)=row(xx(i),yy(i));
end
rowshort = rs;
ks = [];
[x,y] = size(knn);
counti=1;
for i = 1:1:x
    countj=1;
    for j= 1:1:size(yy')
        ks(i,countj) = knn(i,yy(j));
        countj = countj + 1;
    end
end
knnshort = ks;

end

