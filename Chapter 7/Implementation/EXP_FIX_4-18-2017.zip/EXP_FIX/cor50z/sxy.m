function [ out ] = sxy( mat1,mat2)

[x,y] = size(mat1);
m1 = mean(mat1);
m2 = mean(mat2);

num=0;
den=0;
den1 = 0;
den2 = 0;

for i = 1:1:x
    m1xx = mat1(i)-m1;
    m2xx = mat2(i)-m2;
num = num + (m1xx)*(m2xx);
den1 = den1 +(m1xx)*(m1xx);
den2 = den2 +(m2xx)*(m2xx);
end

a = num / (sqrt(den1)*sqrt(den2));
chk = isnan(a);
if chk ==1
    out = -1;
else
out =a;
end

end

