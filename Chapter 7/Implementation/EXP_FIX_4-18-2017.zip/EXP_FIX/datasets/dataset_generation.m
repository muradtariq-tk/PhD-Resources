targetmatrix = sparsmat(ML.ml,0.98);
 
mtsource95 = sparsmat(MT.mt,0.95);
mtsource90 = sparsmat(MT.mt,0.90);
mtsource85 = sparsmat(MT.mt,0.85);
 
fbsource95 = sparsmat(FB.fb,0.95);
fbsource90 = sparsmat(FB.fb,0.90);
fbsource85 = sparsmat(FB.fb,0.85);
