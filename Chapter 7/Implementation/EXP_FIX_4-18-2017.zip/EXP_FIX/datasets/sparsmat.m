function [ret] = sparsmat(imat,val)

ret = [];

[sx,sy] = size(imat);

[zx,zy] = find(imat==0);

tr = sx*sy;

cs = (length(zx)/tr);

if val < cs
    ret = imat;
else
    [rx,ry] = find(imat~=0);
    ratings = length(rx);
    existing_ratings = ratings;
    new_ratings =(tr-tr*val);
    ret = zeros(sx,sy);
    for j = 1:1:new_ratings
        loc = ceil(rand()*length(rx));
        ret(rx(loc),ry(loc)) = imat(rx(loc),ry(loc));
        rx(loc)=[];
        ry(loc)=[];
    end
end
