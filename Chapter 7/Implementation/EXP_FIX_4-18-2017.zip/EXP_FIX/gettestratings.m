function [ratx,raty] = gettestratings(ix,iy)
idx=randperm(numel(ix));

ratx=ix(idx(1:100));
raty=iy(idx(1:100));