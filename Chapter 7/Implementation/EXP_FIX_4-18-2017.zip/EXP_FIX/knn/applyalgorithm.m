function [ pscore,era,mra,rscore,mae ] = applyalgorithm(mat,ratx,raty,testing,N,folder)
[xm,ym] = size(ratx);
till = 10;
ps_ = 0;
rs_ = 0;
mae_= 0;
tpx=0;
tnx=0;
fpx=0;
fnx=0;
mae = 0;
counter = 0;
er = 0;
mr = 0;
ii=1;
while ii<till
testrow = mat(ratx(ii),:);
master_row = testrow;
testrow=master_row;
[xxx,yyy] = find(testrow>=2.5);
[xx,yy] = size(yyy);
loc = ceil(rand*yy);
loc = yyy(loc);
value_of_testrow = testrow(1,raty(ii));
testrow(1,loc) = 0;
row = testrow;
res = [];
[x,y]=size(row);
knnmat = getknnmat(testrow,testing,N,folder);
[fx,fy] = find(row);
output=[];
rowshort=row;
knnshort=knnmat;
%[rowshort,knnshort] = short(row,knnmat);
[xx,yy]=size(fy);

%for i=1:1:yy
    output = getrating(knnmat,row,loc);
    if(output<0)
        output = 0;
    end
   % d=[output value_of_testrow]
    %rowval = row(fx(i),fy(i));
    range = 1;
    [tp,tn,fp,fn] = prec(value_of_testrow,output,range);
    tpx=tpx+tp;
    fpx=fpx+fp;
    
    mae = mae+abs(value_of_testrow-output);
    er = er + extraratings(knnmat,row);
    mr = mr + mappedratings(knnmat,row);
    ii = ii + 1;

end
mae = mae / till;
rscore = 0;
pscore = (tpx)/(tpx+fpx);
era = er/till;
mra = mr/till;
end