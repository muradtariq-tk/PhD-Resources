function [ retmat ] = getknnmat( testrow,matrix,N,folder )
addpath(folder);
ret = [];
for i = 1:1:N
row = mappingalgorithm(testrow,matrix);
ret(i,:)=row;
[~,indx]=ismember(matrix,row,'rows');
loc=find(indx~=0);
matrix(loc(1),:)=[];
end
retmat=ret;
rmpath(folder);
%if N == 0
%    retmat=matrix;
%else
%matrixnew =matrix;
%[x,y]=size(matrix);

%---for i = 1:1:x
%---    matrixnew(i,:)=matrix(i,:).*filter;
%---end

%distance=[];
%calc=0;
%for i =1:1:x
%    testrowshort = testrow;
%    currentshort = matrixnew(i,:);
%    [testrowshort,currentshort]=short(testrow,matrixnew(i,:));
%    if(length(testrowshort)==0 || length(currentshort)==0)
%    distance(i,:) = -1;
%    continue
%    end
%    [testrowshort,currentshort]=short(currentshort,testrowshort);
%    if(length(testrowshort)==0 || length(currentshort)==0)
%    distance(i,:) = -1;
%    continue
%    end
%    distance(i,:)=sxy(testrowshort',currentshort');
%    calc = 0;
%end

%cnt=0;
%for i = 1:1:N
%    cnt=cnt+1;
%    [maxv , maxy]=max(distance);
%    relatedrows(cnt,:)=matrixnew(maxy,:);
%    distance([maxy],:)=-1;
%end
%retmat =relatedrows;
%end
%
%end