function [ valx] = getrating( mat,row,index)
%[xx,yy] = size(mat);
%res=0;
%for i = 1:1:xx
%    res=res+mat(i,index);
%end
%res=res/xx;
%valx=res;
[rowx,rowx]=short(row,row);
kmean = mean(rowx);
[xxx,yyy]=size(mat);
num=0;
den=0;
for i=1:1:xxx
 rowx = row;
 matx = mat(i,:);
[rowx,matx]=short(row,mat(i,:));
[matx,rowx]=short(matx,rowx);
cn=csx(rowx',matx');
s_mean = mean(matx);
v = mat(1,index);
num = num+((v-s_mean)*cn);
den = den+abs(cn);
end
ret = kmean+(num/den);
valx=ret;
