function [tp,tn,fp,fn] = prec(element1,element2, range)
%
tp=0;
tn=0;
fp=0;
fn=0;
if abs(abs(element1)-abs(element2))<range
    tp=1;
else
    fp=1;
end

end