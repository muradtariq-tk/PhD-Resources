function [training] = map_users(target, source, algo)
addpath(algo);
training = mappingalgorithm(target,source);
rmpath(algo);