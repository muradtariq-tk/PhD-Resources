clear all;
close all;
rmpath('sit50');
rmpath('cos50z');
rmpath('cor50z');
rmpath('cov50z');
folder={};
c=3;
n=2;
tries = 10;
%-[ load datasets ]-------------------------
addpath('datasets');
TEMPDS = load('targetmatrix.mat');
targetmatrix = TEMPDS.targetmatrix;
 
TEMPDS = load('mtsource95.mat');
mtsource95 = TEMPDS.mtsource95;
TEMPDS = load('mtsource90.mat');
mtsource90 = TEMPDS.mtsource90;
TEMPDS = load('mtsource85.mat');
mtsource85 = TEMPDS.mtsource85;
 
TEMPDS = load('fbsource95.mat');
fbsource95 = TEMPDS.fbsource95;
TEMPDS = load('fbsource90.mat');
fbsource90 = TEMPDS.fbsource90;
TEMPDS = load('fbsource85.mat');
fbsource85 = TEMPDS.fbsource85;
rmpath('datasets');

Training_percentage = 0.7;

%-[ split testing / training ]-------------------------
addpath('splitcode');
[training,testing] = split_test_training(Training_percentage,targetmatrix);
rmpath('splitcode');

%-[ mapping training users sparsity = .85]--------------
if c == 1
t = [0 0 0 0 0];
tic
training_mtsource85_cor50z = map_users(training,mtsource85,'cor50z');
t(1,1)=toc;
tic
training_mtsource85_cos50z = map_users(training,mtsource85,'cos50z');
t(1,2)=toc;
tic
training_mtsource85_cov50z = map_users(training,mtsource85,'cov50z');
t(1,3)=toc;
tic
training_mtsource85_sitt = map_users(training,mtsource85,'SiT50t');
t(1,4)=toc;
tic
training_mtsource85_sits = map_users(training,mtsource85,'SiT50s');
t(1,5)=toc;

a= [0 0 0 0 0 0];

a(1,1)=length(find(training_mtsource85_cor50z~=0));
a(1,2)=length(find(training_mtsource85_cos50z~=0));
a(1,3)=length(find(training_mtsource85_cov50z~=0));
a(1,4)=length(find(training_mtsource85_sitt~=0));
a(1,5)=length(find(training_mtsource85_sits~=0));
a(1,6)=length(find(training~=0));

addpath('knn');
res=zeros(5,5);
res_total=zeros(5,5);
for i=1:1:tries
    i
[ratx,raty]=find(testing~=0);
[ratx,raty] = gettestratings(ratx,raty);
res(4,:)= knncalc(testing,ratx,raty,training_mtsource85_sitt,n,'SiT50t');
res(1,:) = knncalc(testing,ratx,raty,training_mtsource85_cor50z,n,'cor50z');
res(2,:)= knncalc(testing,ratx,raty,training_mtsource85_cos50z,n,'cos50z');
res(3,:) = knncalc(testing,ratx,raty,training_mtsource85_cov50z,n,'cov50z');
res(5,:) = knncalc(testing,ratx,raty,training_mtsource85_sits,n,'SiT50s');
res_total = res_total+res;
end
res_total =res_total/tries;
rmpath('knn');
end

if c == 2
t = [0 0 0 0 0];
tic
training_mtsource90_cor50z = map_users(training,mtsource90,'cor50z');
t(1,1)=toc;
tic
training_mtsource90_cos50z = map_users(training,mtsource90,'cos50z');
t(1,2)=toc;
tic
training_mtsource90_cov50z = map_users(training,mtsource90,'cov50z');
t(1,3)=toc;
tic
training_mtsource90_sitt = map_users(training,mtsource90,'SiT50t');
t(1,4)=toc;
tic
training_mtsource90_sits = map_users(training,mtsource90,'SiT50s');
t(1,5)=toc;

a= [0 0 0 0 0 0];

a(1,1)=length(find(training_mtsource90_cor50z~=0));
a(1,2)=length(find(training_mtsource90_cos50z~=0));
a(1,3)=length(find(training_mtsource90_cov50z~=0));
a(1,4)=length(find(training_mtsource90_sitt~=0));
a(1,5)=length(find(training_mtsource90_sits~=0));
a(1,6)=length(find(training~=0));

addpath('knn');
res=zeros(5,5);
res_total=zeros(5,5);
for i=1:1:tries
    i
[ratx,raty]=find(testing~=0);
[ratx,raty] = gettestratings(ratx,raty);
res(4,:)= knncalc(testing,ratx,raty,training_mtsource90_sitt,n,'SiT50t');
res(1,:) = knncalc(testing,ratx,raty,training_mtsource90_cor50z,n,'cor50z');
res(2,:)= knncalc(testing,ratx,raty,training_mtsource90_cos50z,n,'cos50z');
res(3,:) = knncalc(testing,ratx,raty,training_mtsource90_cov50z,n,'cov50z');
res(5,:) = knncalc(testing,ratx,raty,training_mtsource90_sits,n,'SiT50s');
res_total = res_total+res;
end
res_total =res_total/tries;
rmpath('knn');
end
if c == 3
t = [0 0 0 0 0];
tic
training_mtsource95_cor50z = map_users(training,mtsource95,'cor50z');
t(1,1)=toc;
tic
training_mtsource95_cos50z = map_users(training,mtsource95,'cos50z');
t(1,2)=toc;
tic
training_mtsource95_cov50z = map_users(training,mtsource95,'cov50z');
t(1,3)=toc;
tic
training_mtsource95_sitt = map_users(training,mtsource95,'SiT50t');
t(1,4)=toc;
tic
training_mtsource95_sits = map_users(training,mtsource95,'SiT50s');
t(1,5)=toc;
 
a= [0 0 0 0 0 0];
 
a(1,1)=length(find(training_mtsource95_cor50z~=0));
a(1,2)=length(find(training_mtsource95_cos50z~=0));
a(1,3)=length(find(training_mtsource95_cov50z~=0));
a(1,4)=length(find(training_mtsource95_sitt~=0));
a(1,5)=length(find(training_mtsource95_sits~=0));
a(1,6)=length(find(training~=0));
 
addpath('knn');
res=zeros(5,5);
res_total=zeros(5,5);
for i=1:1:tries
    i
[ratx,raty]=find(testing~=0);
[ratx,raty] = gettestratings(ratx,raty);
res(4,:)= knncalc(testing,ratx,raty,training_mtsource95_sitt,n,'SiT50t');
res(1,:) = knncalc(testing,ratx,raty,training_mtsource95_cor50z,n,'cor50z');
res(2,:)= knncalc(testing,ratx,raty,training_mtsource95_cos50z,n,'cos50z');
res(3,:) = knncalc(testing,ratx,raty,training_mtsource95_cov50z,n,'cov50z');
res(5,:) = knncalc(testing,ratx,raty,training_mtsource95_sits,n,'SiT50s');
res_total = res_total+res;
end
res_total =res_total/tries;
rmpath('knn');
end



res_total