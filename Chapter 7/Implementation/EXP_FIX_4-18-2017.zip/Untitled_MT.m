x=[1:1:10];
c1_cor_acc = (graphg(get10('MT_C1_A',1,1),get10('MT_C1_B',1,1))/(100))';
c1_cos_acc = (graphg(get10('MT_C1_A',2,1),get10('MT_C1_B',2,1))/(100))';
c1_sitt_acc = (graphg(get10('MT_C1_A',3,1),get10('MT_C1_B',3,1))/(100))';
c1_sits_acc = (graphg(get10('MT_C1_A',4,1),get10('MT_C1_B',4,1))/(100))';
 
c1_cor_er = (graphg(get10('MT_C1_A',1,2),get10('MT_C1_B',1,2))/(100))';
c1_cos_er = (graphg(get10('MT_C1_A',2,2),get10('MT_C1_B',2,2))/(100))';
c1_sitt_er = (graphg(get10('MT_C1_A',3,2),get10('MT_C1_B',3,2))/(100))';
c1_sits_er = (graphg(get10('MT_C1_A',4,2),get10('MT_C1_B',4,2))/(100))';
 
c1_cor_mr = (graphg(get10('MT_C1_A',1,3),get10('MT_C1_B',1,3))/(100))';
c1_cos_mr = (graphg(get10('MT_C1_A',2,3),get10('MT_C1_B',2,3))/(100))';
c1_sitt_mr = (graphg(get10('MT_C1_A',3,3),get10('MT_C1_B',3,3))/(100))';
c1_sits_mr = (graphg(get10('MT_C1_A',4,3),get10('MT_C1_B',4,3))/(100))';
 
c1_cor_mae = (graphd(get10('MT_C1_A',1,5),get10('MT_C1_B',1,5))/(100))';
c1_cos_mae = (graphd(get10('MT_C1_A',2,5),get10('MT_C1_B',2,5))/(100))';
c1_sitt_mae = (graphd(get10('MT_C1_A',3,5),get10('MT_C1_B',3,5))/(100))';
c1_sits_mae = (graphd(get10('MT_C1_A',4,5),get10('MT_C1_B',4,5))/(100))';
 
set(0,'DefaultAxesColorOrder',[0 0 0],...
      'DefaultAxesLineStyleOrder',{':s',':o','-o','-*','--+'})
 
plot(x,c1_cor_mr);
hold all
plot(x,c1_cos_mr);
hold all
plot(x,c1_sitt_mr);
hold all
plot(x,c1_sits_mr);
hold all
 
title('Mapped ratings for 0.85 Spars MTIMDB training set');
xlabel('Number of users');
ylabel('Mapped ratings');

