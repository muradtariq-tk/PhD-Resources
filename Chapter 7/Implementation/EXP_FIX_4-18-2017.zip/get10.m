function [ret] = get10(name,algo,eva)
load(name);
r=[];
for i = 1:1:10
temp=restruct{i};
ret(i) = temp(algo,eva);
end
clear('restruct');
