function [ret] =graphd(inp1,inp2)
min1 = min(inp1);
min2 = min(inp2);
max1 = max(inp1);
max2 = max(inp2);
smin = 0 ;
smax = 0;

if min1<min2
    smin = min1;
else
    smin = min2;
end
if max1>max2
    smax = max1;
else
    smax = max2;
end
next =smax;
v=[];
for i=1:1:9
v(i) = (smin*.5)+(next*.5);
next = v(i);
end
ret = [smax v];